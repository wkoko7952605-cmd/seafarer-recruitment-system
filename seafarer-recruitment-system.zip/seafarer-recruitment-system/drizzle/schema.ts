import { int, mysqlEnum, mysqlTable, text, timestamp, varchar, decimal, boolean, date, longtext, index } from "drizzle-orm/mysql-core";

/**
 * Core user table backing auth flow.
 * Extended with role field to support seafarer, employer, and admin roles.
 */
export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["seafarer", "employer", "admin"]).default("seafarer").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

/**
 * Seafarer profiles - detailed information about maritime crew members
 */
export const seafarers = mysqlTable("seafarers", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  firstName: varchar("firstName", { length: 100 }).notNull(),
  lastName: varchar("lastName", { length: 100 }).notNull(),
  dateOfBirth: date("dateOfBirth"),
  nationality: varchar("nationality", { length: 100 }),
  passportNumber: varchar("passportNumber", { length: 50 }),
  rank: varchar("rank", { length: 100 }), // e.g., Captain, Chief Officer, Engineer
  yearsOfExperience: int("yearsOfExperience"),
  bio: longtext("bio"),
  profileCompletionPercentage: int("profileCompletionPercentage").default(0),
  isApproved: boolean("isApproved").default(false),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
}, (table) => ({
  userIdIdx: index("userIdIdx").on(table.userId),
}));

export type Seafarer = typeof seafarers.$inferSelect;
export type InsertSeafarer = typeof seafarers.$inferInsert;

/**
 * Work experience history for seafarers
 */
export const workExperience = mysqlTable("workExperience", {
  id: int("id").autoincrement().primaryKey(),
  seafarerId: int("seafarerId").notNull(),
  companyName: varchar("companyName", { length: 200 }).notNull(),
  position: varchar("position", { length: 100 }).notNull(),
  shipType: varchar("shipType", { length: 100 }),
  startDate: date("startDate").notNull(),
  endDate: date("endDate"),
  description: longtext("description"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
}, (table) => ({
  seafarerIdIdx: index("seafarerIdIdx").on(table.seafarerId),
}));

export type WorkExperience = typeof workExperience.$inferSelect;
export type InsertWorkExperience = typeof workExperience.$inferInsert;

/**
 * Certificates and documents for seafarers
 */
export const certificates = mysqlTable("certificates", {
  id: int("id").autoincrement().primaryKey(),
  seafarerId: int("seafarerId").notNull(),
  certificateType: varchar("certificateType", { length: 100 }).notNull(), // CDC, STCW, etc.
  certificateNumber: varchar("certificateNumber", { length: 100 }),
  issuedDate: date("issuedDate"),
  expiryDate: date("expiryDate").notNull(),
  fileKey: varchar("fileKey", { length: 255 }), // S3 storage key
  fileUrl: varchar("fileUrl", { length: 500 }), // Access URL
  issuingCountry: varchar("issuingCountry", { length: 100 }),
  status: mysqlEnum("status", ["valid", "expiring_soon", "expired"]).default("valid"),
  notificationSent30Days: boolean("notificationSent30Days").default(false),
  notificationSent60Days: boolean("notificationSent60Days").default(false),
  notificationSent90Days: boolean("notificationSent90Days").default(false),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
}, (table) => ({
  seafarerIdIdx: index("seafarerIdIdx").on(table.seafarerId),
  expiryDateIdx: index("expiryDateIdx").on(table.expiryDate),
}));

export type Certificate = typeof certificates.$inferSelect;
export type InsertCertificate = typeof certificates.$inferInsert;

/**
 * CV and document uploads for seafarers
 */
export const documents = mysqlTable("documents", {
  id: int("id").autoincrement().primaryKey(),
  seafarerId: int("seafarerId").notNull(),
  documentType: varchar("documentType", { length: 100 }).notNull(), // CV, Passport, etc.
  fileName: varchar("fileName", { length: 255 }).notNull(),
  fileKey: varchar("fileKey", { length: 255 }).notNull(), // S3 storage key
  fileUrl: varchar("fileUrl", { length: 500 }), // Access URL
  mimeType: varchar("mimeType", { length: 100 }),
  fileSize: int("fileSize"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
}, (table) => ({
  seafarerIdIdx: index("seafarerIdIdx").on(table.seafarerId),
}));

export type Document = typeof documents.$inferSelect;
export type InsertDocument = typeof documents.$inferInsert;

/**
 * Job postings created by admins
 */
export const jobs = mysqlTable("jobs", {
  id: int("id").autoincrement().primaryKey(),
  title: varchar("title", { length: 200 }).notNull(),
  description: longtext("description").notNull(),
  shipType: varchar("shipType", { length: 100 }).notNull(),
  requiredPositions: varchar("requiredPositions", { length: 500 }).notNull(), // JSON array as string
  requiredRank: varchar("requiredRank", { length: 100 }),
  minExperience: int("minExperience"),
  salary: varchar("salary", { length: 100 }),
  contractDuration: varchar("contractDuration", { length: 100 }), // e.g., "6 months"
  location: varchar("location", { length: 200 }),
  status: mysqlEnum("status", ["open", "closed", "filled"]).default("open"),
  createdBy: int("createdBy").notNull(), // Admin user ID
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
}, (table) => ({
  statusIdx: index("statusIdx").on(table.status),
  createdByIdx: index("createdByIdx").on(table.createdBy),
}));

export type Job = typeof jobs.$inferSelect;
export type InsertJob = typeof jobs.$inferInsert;

/**
 * Job applications from seafarers
 */
export const applications = mysqlTable("applications", {
  id: int("id").autoincrement().primaryKey(),
  jobId: int("jobId").notNull(),
  seafarerId: int("seafarerId").notNull(),
  status: mysqlEnum("status", ["pending", "accepted", "rejected", "withdrawn"]).default("pending"),
  matchScore: decimal("matchScore", { precision: 5, scale: 2 }), // LLM matching score
  appliedAt: timestamp("appliedAt").defaultNow().notNull(),
  reviewedAt: timestamp("reviewedAt"),
  reviewedBy: int("reviewedBy"), // Admin user ID
}, (table) => ({
  jobIdIdx: index("jobIdIdx").on(table.jobId),
  seafarerIdIdx: index("seafarerIdIdx").on(table.seafarerId),
  statusIdx: index("statusIdx").on(table.status),
}));

export type Application = typeof applications.$inferSelect;
export type InsertApplication = typeof applications.$inferInsert;

/**
 * Employer companies
 */
export const employers = mysqlTable("employers", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  companyName: varchar("companyName", { length: 200 }).notNull(),
  registrationNumber: varchar("registrationNumber", { length: 100 }),
  industry: varchar("industry", { length: 100 }),
  country: varchar("country", { length: 100 }),
  contactPerson: varchar("contactPerson", { length: 200 }),
  contactEmail: varchar("contactEmail", { length: 320 }),
  contactPhone: varchar("contactPhone", { length: 20 }),
  companyDescription: longtext("companyDescription"),
  isApproved: boolean("isApproved").default(false),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
}, (table) => ({
  userIdIdx: index("userIdIdx").on(table.userId),
}));

export type Employer = typeof employers.$inferSelect;
export type InsertEmployer = typeof employers.$inferInsert;

/**
 * Crew requests from employers
 */
export const crewRequests = mysqlTable("crewRequests", {
  id: int("id").autoincrement().primaryKey(),
  employerId: int("employerId").notNull(),
  shipType: varchar("shipType", { length: 100 }).notNull(),
  requiredPositions: varchar("requiredPositions", { length: 500 }).notNull(), // JSON array as string
  numberOfCrew: int("numberOfCrew").notNull(),
  preferredRank: varchar("preferredRank", { length: 100 }),
  minExperience: int("minExperience"),
  additionalRequirements: longtext("additionalRequirements"),
  status: mysqlEnum("status", ["pending", "approved", "rejected", "fulfilled"]).default("pending"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
}, (table) => ({
  employerIdIdx: index("employerIdIdx").on(table.employerId),
  statusIdx: index("statusIdx").on(table.status),
}));

export type CrewRequest = typeof crewRequests.$inferSelect;
export type InsertCrewRequest = typeof crewRequests.$inferInsert;

/**
 * Maritime news and industry updates
 */
export const maritimeNews = mysqlTable("maritimeNews", {
  id: int("id").autoincrement().primaryKey(),
  title: varchar("title", { length: 300 }).notNull(),
  content: longtext("content").notNull(),
  category: varchar("category", { length: 100 }), // News, Career Tips, Regulations, etc.
  imageUrl: varchar("imageUrl", { length: 500 }),
  isPublished: boolean("isPublished").default(false),
  createdBy: int("createdBy").notNull(), // Admin user ID
  publishedAt: timestamp("publishedAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
}, (table) => ({
  isPublishedIdx: index("isPublishedIdx").on(table.isPublished),
  createdByIdx: index("createdByIdx").on(table.createdBy),
}));

export type MaritimeNews = typeof maritimeNews.$inferSelect;
export type InsertMaritimeNews = typeof maritimeNews.$inferInsert;

/**
 * Notification logs for tracking sent notifications
 */
export const notificationLogs = mysqlTable("notificationLogs", {
  id: int("id").autoincrement().primaryKey(),
  recipientId: int("recipientId").notNull(), // User ID
  notificationType: varchar("notificationType", { length: 100 }).notNull(), // certificate_expiry, application_status, etc.
  certificateId: int("certificateId"), // For certificate expiry notifications
  subject: varchar("subject", { length: 300 }).notNull(),
  message: longtext("message"),
  status: mysqlEnum("status", ["sent", "failed", "pending"]).default("pending"),
  sentAt: timestamp("sentAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
}, (table) => ({
  recipientIdIdx: index("recipientIdIdx").on(table.recipientId),
  notificationTypeIdx: index("notificationTypeIdx").on(table.notificationType),
}));

export type NotificationLog = typeof notificationLogs.$inferSelect;
export type InsertNotificationLog = typeof notificationLogs.$inferInsert;