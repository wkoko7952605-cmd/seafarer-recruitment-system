CREATE TABLE `applications` (
	`id` int AUTO_INCREMENT NOT NULL,
	`jobId` int NOT NULL,
	`seafarerId` int NOT NULL,
	`status` enum('pending','accepted','rejected','withdrawn') DEFAULT 'pending',
	`matchScore` decimal(5,2),
	`appliedAt` timestamp NOT NULL DEFAULT (now()),
	`reviewedAt` timestamp,
	`reviewedBy` int,
	CONSTRAINT `applications_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `certificates` (
	`id` int AUTO_INCREMENT NOT NULL,
	`seafarerId` int NOT NULL,
	`certificateType` varchar(100) NOT NULL,
	`certificateNumber` varchar(100),
	`issuedDate` date,
	`expiryDate` date NOT NULL,
	`fileKey` varchar(255),
	`fileUrl` varchar(500),
	`issuingCountry` varchar(100),
	`status` enum('valid','expiring_soon','expired') DEFAULT 'valid',
	`notificationSent30Days` boolean DEFAULT false,
	`notificationSent60Days` boolean DEFAULT false,
	`notificationSent90Days` boolean DEFAULT false,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `certificates_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `crewRequests` (
	`id` int AUTO_INCREMENT NOT NULL,
	`employerId` int NOT NULL,
	`shipType` varchar(100) NOT NULL,
	`requiredPositions` varchar(500) NOT NULL,
	`numberOfCrew` int NOT NULL,
	`preferredRank` varchar(100),
	`minExperience` int,
	`additionalRequirements` longtext,
	`status` enum('pending','approved','rejected','fulfilled') DEFAULT 'pending',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `crewRequests_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `documents` (
	`id` int AUTO_INCREMENT NOT NULL,
	`seafarerId` int NOT NULL,
	`documentType` varchar(100) NOT NULL,
	`fileName` varchar(255) NOT NULL,
	`fileKey` varchar(255) NOT NULL,
	`fileUrl` varchar(500),
	`mimeType` varchar(100),
	`fileSize` int,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `documents_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `employers` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`companyName` varchar(200) NOT NULL,
	`registrationNumber` varchar(100),
	`industry` varchar(100),
	`country` varchar(100),
	`contactPerson` varchar(200),
	`contactEmail` varchar(320),
	`contactPhone` varchar(20),
	`companyDescription` longtext,
	`isApproved` boolean DEFAULT false,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `employers_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `jobs` (
	`id` int AUTO_INCREMENT NOT NULL,
	`title` varchar(200) NOT NULL,
	`description` longtext NOT NULL,
	`shipType` varchar(100) NOT NULL,
	`requiredPositions` varchar(500) NOT NULL,
	`requiredRank` varchar(100),
	`minExperience` int,
	`salary` varchar(100),
	`contractDuration` varchar(100),
	`location` varchar(200),
	`status` enum('open','closed','filled') DEFAULT 'open',
	`createdBy` int NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `jobs_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `maritimeNews` (
	`id` int AUTO_INCREMENT NOT NULL,
	`title` varchar(300) NOT NULL,
	`content` longtext NOT NULL,
	`category` varchar(100),
	`imageUrl` varchar(500),
	`isPublished` boolean DEFAULT false,
	`createdBy` int NOT NULL,
	`publishedAt` timestamp,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `maritimeNews_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `notificationLogs` (
	`id` int AUTO_INCREMENT NOT NULL,
	`recipientId` int NOT NULL,
	`notificationType` varchar(100) NOT NULL,
	`certificateId` int,
	`subject` varchar(300) NOT NULL,
	`message` longtext,
	`status` enum('sent','failed','pending') DEFAULT 'pending',
	`sentAt` timestamp,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `notificationLogs_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `seafarers` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`firstName` varchar(100) NOT NULL,
	`lastName` varchar(100) NOT NULL,
	`dateOfBirth` date,
	`nationality` varchar(100),
	`passportNumber` varchar(50),
	`rank` varchar(100),
	`yearsOfExperience` int,
	`bio` longtext,
	`profileCompletionPercentage` int DEFAULT 0,
	`isApproved` boolean DEFAULT false,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `seafarers_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `workExperience` (
	`id` int AUTO_INCREMENT NOT NULL,
	`seafarerId` int NOT NULL,
	`companyName` varchar(200) NOT NULL,
	`position` varchar(100) NOT NULL,
	`shipType` varchar(100),
	`startDate` date NOT NULL,
	`endDate` date,
	`description` longtext,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `workExperience_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
ALTER TABLE `users` MODIFY COLUMN `role` enum('seafarer','employer','admin') NOT NULL DEFAULT 'seafarer';--> statement-breakpoint
CREATE INDEX `jobIdIdx` ON `applications` (`jobId`);--> statement-breakpoint
CREATE INDEX `seafarerIdIdx` ON `applications` (`seafarerId`);--> statement-breakpoint
CREATE INDEX `statusIdx` ON `applications` (`status`);--> statement-breakpoint
CREATE INDEX `seafarerIdIdx` ON `certificates` (`seafarerId`);--> statement-breakpoint
CREATE INDEX `expiryDateIdx` ON `certificates` (`expiryDate`);--> statement-breakpoint
CREATE INDEX `employerIdIdx` ON `crewRequests` (`employerId`);--> statement-breakpoint
CREATE INDEX `statusIdx` ON `crewRequests` (`status`);--> statement-breakpoint
CREATE INDEX `seafarerIdIdx` ON `documents` (`seafarerId`);--> statement-breakpoint
CREATE INDEX `userIdIdx` ON `employers` (`userId`);--> statement-breakpoint
CREATE INDEX `statusIdx` ON `jobs` (`status`);--> statement-breakpoint
CREATE INDEX `createdByIdx` ON `jobs` (`createdBy`);--> statement-breakpoint
CREATE INDEX `isPublishedIdx` ON `maritimeNews` (`isPublished`);--> statement-breakpoint
CREATE INDEX `createdByIdx` ON `maritimeNews` (`createdBy`);--> statement-breakpoint
CREATE INDEX `recipientIdIdx` ON `notificationLogs` (`recipientId`);--> statement-breakpoint
CREATE INDEX `notificationTypeIdx` ON `notificationLogs` (`notificationType`);--> statement-breakpoint
CREATE INDEX `userIdIdx` ON `seafarers` (`userId`);--> statement-breakpoint
CREATE INDEX `seafarerIdIdx` ON `workExperience` (`seafarerId`);