import { useState, useRef } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Upload, X, FileText, CheckCircle, AlertCircle } from "lucide-react";
import { toast } from "sonner";

interface DocumentUploadProps {
  onUploadComplete?: (fileKey: string, fileUrl: string, fileName: string) => void;
  documentType: "cv" | "certificate" | "passport" | "other";
  maxSizeMB?: number;
}

export function DocumentUpload({
  onUploadComplete,
  documentType,
  maxSizeMB = 10,
}: DocumentUploadProps) {
  const [isUploading, setIsUploading] = useState(false);
  const [uploadedFile, setUploadedFile] = useState<{
    name: string;
    size: number;
    uploadedAt: Date;
  } | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileSelect = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    // Validate file size
    const fileSizeMB = file.size / (1024 * 1024);
    if (fileSizeMB > maxSizeMB) {
      toast.error(`File size must be less than ${maxSizeMB}MB`);
      return;
    }

    // Validate file type
    const allowedTypes = ["application/pdf", "image/jpeg", "image/png", "application/msword"];
    if (!allowedTypes.includes(file.type)) {
      toast.error("Only PDF, JPEG, PNG, and DOC files are allowed");
      return;
    }

    setIsUploading(true);
    try {
      // Create FormData for file upload
      const formData = new FormData();
      formData.append("file", file);
      formData.append("documentType", documentType);

      // Upload to backend
      const response = await fetch("/api/upload", {
        method: "POST",
        body: formData,
      });

      if (!response.ok) {
        throw new Error("Upload failed");
      }

      const data = await response.json();
      setUploadedFile({
        name: file.name,
        size: file.size,
        uploadedAt: new Date(),
      });

      toast.success("File uploaded successfully");
      onUploadComplete?.(data.fileKey, data.fileUrl, file.name);
    } catch (error) {
      toast.error("Failed to upload file");
      console.error("Upload error:", error);
    } finally {
      setIsUploading(false);
      if (fileInputRef.current) {
        fileInputRef.current.value = "";
      }
    }
  };

  const handleClear = () => {
    setUploadedFile(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = "";
    }
  };

  return (
    <Card className="bg-slate-800 border-slate-700 p-6">
      <div className="space-y-4">
        {/* Upload Area */}
        {!uploadedFile ? (
          <div
            className="border-2 border-dashed border-slate-600 rounded-lg p-8 text-center hover:border-blue-500 transition-colors cursor-pointer"
            onClick={() => fileInputRef.current?.click()}
          >
            <Upload className="w-12 h-12 text-slate-400 mx-auto mb-3" />
            <p className="text-slate-300 font-medium mb-1">
              Drop your file here or click to browse
            </p>
            <p className="text-slate-400 text-sm">
              Supported formats: PDF, JPEG, PNG, DOC (Max {maxSizeMB}MB)
            </p>
            <input
              ref={fileInputRef}
              type="file"
              onChange={handleFileSelect}
              disabled={isUploading}
              className="hidden"
              accept=".pdf,.jpg,.jpeg,.png,.doc,.docx"
            />
          </div>
        ) : (
          /* Uploaded File Display */
          <div className="bg-slate-700/50 rounded-lg p-4 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <CheckCircle className="w-6 h-6 text-green-500" />
              <div>
                <p className="text-slate-200 font-medium truncate">{uploadedFile.name}</p>
                <p className="text-slate-400 text-sm">
                  {(uploadedFile.size / 1024).toFixed(2)} KB • Uploaded{" "}
                  {uploadedFile.uploadedAt.toLocaleDateString()}
                </p>
              </div>
            </div>
            <Button
              variant="ghost"
              size="sm"
              onClick={handleClear}
              className="text-slate-400 hover:text-red-400"
            >
              <X className="w-4 h-4" />
            </Button>
          </div>
        )}

        {/* Upload Button */}
        {!uploadedFile && (
          <Button
            onClick={() => fileInputRef.current?.click()}
            disabled={isUploading}
            className="w-full bg-blue-600 hover:bg-blue-700"
          >
            {isUploading ? (
              <>
                <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                Uploading...
              </>
            ) : (
              <>
                <Upload className="w-4 h-4 mr-2" />
                Select File
              </>
            )}
          </Button>
        )}

        {/* Info Message */}
        <div className="bg-blue-900/30 border border-blue-700/50 rounded-lg p-3 flex gap-2">
          <AlertCircle className="w-5 h-5 text-blue-400 flex-shrink-0 mt-0.5" />
          <p className="text-blue-300 text-sm">
            Your documents are securely stored and only accessible to you and authorized administrators.
          </p>
        </div>
      </div>
    </Card>
  );
}
