import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/NotFound";
import { Route, Switch } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import Home from "./pages/Home";
import { useAuth } from "./_core/hooks/useAuth";
import SeafarerDashboard from "./pages/SeafarerDashboard";
import { lazy, Suspense } from "react";
import MaritimeNews from "./pages/MaritimeNews";

// Lazy load admin and employer dashboards
const AdminDashboard = lazy(() => import("./pages/AdminDashboard"));
const EmployerDashboard = lazy(() => import("./pages/EmployerDashboard"));

// Protected route wrapper
function ProtectedRoute({ 
  component: Component, 
  requiredRole 
}: { 
  component: React.ComponentType<any>; 
  requiredRole?: string;
}) {
  const { user, loading, isAuthenticated } = useAuth();

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-slate-900 to-slate-800">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-500"></div>
      </div>
    );
  }

  if (!isAuthenticated) {
    return <NotFound />;
  }

  if (requiredRole && user?.role !== requiredRole) {
    return <NotFound />;
  }

  return (
    <Suspense fallback={
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-slate-900 to-slate-800">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-500"></div>
      </div>
    }>
      <Component />
    </Suspense>
  );
}

function Router() {
  return (
    <Switch>
      <Route path={"/"} component={Home} />
      <Route path={"/news"} component={MaritimeNews} />
      
      {/* Seafarer Routes */}
      <Route path={"/seafarer/dashboard"}>
        {() => <ProtectedRoute component={SeafarerDashboard} requiredRole="seafarer" />}
      </Route>

      {/* Employer Routes */}
      <Route path={"/employer/dashboard"}>
        {() => (
          <ProtectedRoute component={EmployerDashboard} requiredRole="employer" />
        )}
      </Route>

      {/* Admin Routes */}
      <Route path={"/admin/dashboard"}>
        {() => (
          <ProtectedRoute component={AdminDashboard} requiredRole="admin" />
        )}
      </Route>

      <Route path={"/404"} component={NotFound} />
      {/* Final fallback route */}
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider defaultTheme="dark">
        <TooltipProvider>
          <Toaster />
          <Router />
        </TooltipProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;
