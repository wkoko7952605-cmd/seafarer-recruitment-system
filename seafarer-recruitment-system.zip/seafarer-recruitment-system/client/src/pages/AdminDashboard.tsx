import { useAuth } from "@/_core/hooks/useAuth";
import DashboardLayout from "@/components/DashboardLayout";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Users, Briefcase, FileText, TrendingUp, CheckCircle, XCircle, Plus } from "lucide-react";
import { trpc } from "@/lib/trpc";
import { useState } from "react";
import { toast } from "sonner";

export default function AdminDashboard() {
  const { user } = useAuth();
  const [activeTab, setActiveTab] = useState("dashboard");
  const [isNewsDialogOpen, setIsNewsDialogOpen] = useState(false);

  // Queries
  const seafarersQuery = trpc.admin.getAllSeafarers.useQuery();
  const newsQuery = trpc.public.getNews.useQuery();

  // Mutations
  const approveSeafarerMutation = trpc.admin.approveSeafarer.useMutation({
    onSuccess: () => {
      toast.success("Seafarer approved!");
      seafarersQuery.refetch();
    },
    onError: (error: any) => {
      toast.error(error.message || "Failed to approve seafarer");
    },
  });

  // Reject is handled via approveSeafarer with isApproved: false
  // const rejectSeafarerMutation = trpc.admin.rejectSeafarer.useMutation({
  //   onSuccess: () => {
  //     toast.success("Seafarer rejected!");
  //     seafarersQuery.refetch();
  //   },
  //   onError: (error: any) => {
  //     toast.error(error.message || "Failed to reject seafarer");
  //   },
  // });

  const createNewsMutation = trpc.admin.createNews.useMutation({
    onSuccess: () => {
      toast.success("News created successfully!");
      setIsNewsDialogOpen(false);
      newsQuery.refetch();
    },
    onError: (error: any) => {
      toast.error(error.message || "Failed to create news");
    },
  });

  // Get pending seafarers
  const pendingSeafarers = (seafarersQuery.data || []).filter((s: any) => !s.isApproved);
  const approvedSeafarers = (seafarersQuery.data || []).filter((s: any) => s.isApproved);

  return (
    <DashboardLayout>
      <div className="space-y-6">
        {/* Header */}
        <div>
          <h1 className="text-3xl font-bold text-white">Admin Dashboard</h1>
          <p className="text-slate-400 mt-2">Manage platform users, content, and operations</p>
        </div>

        {/* Stats */}
        <div className="grid md:grid-cols-4 gap-4">
          <Card className="bg-slate-800/50 border-slate-700 p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-slate-400 text-sm">Total Seafarers</p>
                <p className="text-3xl font-bold text-white mt-2">{seafarersQuery.data?.length || 0}</p>
              </div>
              <Users className="w-10 h-10 text-blue-500 opacity-50" />
            </div>
          </Card>

          <Card className="bg-slate-800/50 border-slate-700 p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-slate-400 text-sm">Pending Approval</p>
                <p className="text-3xl font-bold text-white mt-2">{pendingSeafarers.length}</p>
              </div>
              <FileText className="w-10 h-10 text-yellow-500 opacity-50" />
            </div>
          </Card>

          <Card className="bg-slate-800/50 border-slate-700 p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-slate-400 text-sm">Approved</p>
                <p className="text-3xl font-bold text-white mt-2">{approvedSeafarers.length}</p>
              </div>
              <CheckCircle className="w-10 h-10 text-green-500 opacity-50" />
            </div>
          </Card>

          <Card className="bg-slate-800/50 border-slate-700 p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-slate-400 text-sm">News Articles</p>
                <p className="text-3xl font-bold text-white mt-2">{newsQuery.data?.length || 0}</p>
              </div>
              <TrendingUp className="w-10 h-10 text-purple-500 opacity-50" />
            </div>
          </Card>
        </div>

        {/* Main Tabs */}
        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <TabsList className="bg-slate-800 border border-slate-700">
            <TabsTrigger value="dashboard" className="data-[state=active]:bg-blue-600">
              Dashboard
            </TabsTrigger>
            <TabsTrigger value="seafarers" className="data-[state=active]:bg-blue-600">
              Seafarers
            </TabsTrigger>
            <TabsTrigger value="news" className="data-[state=active]:bg-blue-600">
              Maritime News
            </TabsTrigger>
          </TabsList>

          {/* Dashboard Tab */}
          <TabsContent value="dashboard" className="space-y-4">
            <h2 className="text-2xl font-bold text-white">Platform Overview</h2>

            <div className="grid md:grid-cols-2 gap-4">
              <Card className="bg-slate-800/50 border-slate-700 p-6">
                <h3 className="text-lg font-semibold text-white mb-4">Pending Approvals</h3>
                {pendingSeafarers.length > 0 ? (
                  <p className="text-slate-300">
                    {pendingSeafarers.length} seafarer(s) awaiting approval. Review them in the Seafarers tab.
                  </p>
                ) : (
                  <p className="text-slate-400">All seafarers have been reviewed.</p>
                )}
              </Card>

              <Card className="bg-slate-800/50 border-slate-700 p-6">
                <h3 className="text-lg font-semibold text-white mb-4">System Health</h3>
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-slate-300">Database</span>
                    <span className="text-green-400 font-semibold">✓ Connected</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-slate-300">API Server</span>
                    <span className="text-green-400 font-semibold">✓ Running</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-slate-300">Email Service</span>
                    <span className="text-green-400 font-semibold">✓ Active</span>
                  </div>
                </div>
              </Card>
            </div>
          </TabsContent>

          {/* Seafarers Tab */}
          <TabsContent value="seafarers" className="space-y-4">
            <h2 className="text-2xl font-bold text-white">Seafarer Management</h2>

            {/* Pending Seafarers */}
            {pendingSeafarers.length > 0 && (
              <div className="space-y-3">
                <h3 className="text-lg font-semibold text-yellow-400">Pending Approval ({pendingSeafarers.length})</h3>
                {pendingSeafarers.map((seafarer: any) => (
                  <Card key={seafarer.id} className="bg-slate-800/50 border-slate-700 p-4">
                    <div className="flex items-start justify-between mb-3">
                      <div>
                        <h4 className="font-semibold text-white">
                          {seafarer.firstName} {seafarer.lastName}
                        </h4>
                        <p className="text-sm text-slate-400">Rank: {seafarer.rank || "Not specified"}</p>
                        <p className="text-sm text-slate-400">
                          Experience: {seafarer.yearsOfExperience || 0} years
                        </p>
                      </div>
                      <div className="flex gap-2">
                        <Button
                          size="sm"
                          onClick={() =>
                            approveSeafarerMutation.mutate({
                              seafarerId: seafarer.id,
                            })
                          }
                          className="bg-green-600 hover:bg-green-700 text-white"
                        >
                          <CheckCircle className="w-4 h-4 mr-1" />
                          Approve
                        </Button>
                        <Button
                          size="sm"
                          onClick={() =>
                            approveSeafarerMutation.mutate({
                              seafarerId: seafarer.id,
                            })
                          }
                          className="bg-red-600 hover:bg-red-700 text-white"
                        >
                          <XCircle className="w-4 h-4 mr-1" />
                          Reject
                        </Button>
                      </div>
                    </div>
                    {seafarer.bio && (
                      <p className="text-slate-300 text-sm mt-2">{seafarer.bio}</p>
                    )}
                  </Card>
                ))}
              </div>
            )}

            {/* Approved Seafarers */}
            {approvedSeafarers.length > 0 && (
              <div className="space-y-3">
                <h3 className="text-lg font-semibold text-green-400">Approved Seafarers ({approvedSeafarers.length})</h3>
                {approvedSeafarers.slice(0, 5).map((seafarer: any) => (
                  <Card key={seafarer.id} className="bg-slate-800/50 border-slate-700 p-4">
                    <div className="flex items-start justify-between">
                      <div>
                        <h4 className="font-semibold text-white">
                          {seafarer.firstName} {seafarer.lastName}
                        </h4>
                        <p className="text-sm text-slate-400">Rank: {seafarer.rank || "Not specified"}</p>
                        <p className="text-sm text-slate-400">
                          Experience: {seafarer.yearsOfExperience || 0} years
                        </p>
                      </div>
                      <Badge className="bg-green-900/50 text-green-200 border-green-700">Approved</Badge>
                    </div>
                  </Card>
                ))}
                {approvedSeafarers.length > 5 && (
                  <p className="text-slate-400 text-sm">
                    Showing 5 of {approvedSeafarers.length} approved seafarers
                  </p>
                )}
              </div>
            )}

            {seafarersQuery.isLoading && <div className="text-slate-400">Loading seafarers...</div>}
            {!seafarersQuery.isLoading && (seafarersQuery.data || []).length === 0 && (
              <Card className="bg-slate-800/50 border-slate-700 p-6 text-center">
                <p className="text-slate-400">No seafarers registered yet.</p>
              </Card>
            )}
          </TabsContent>

          {/* News Tab */}
          <TabsContent value="news" className="space-y-4">
            <div className="flex justify-between items-center">
              <h2 className="text-2xl font-bold text-white">Maritime News Management</h2>
              <Dialog open={isNewsDialogOpen} onOpenChange={setIsNewsDialogOpen}>
                <DialogTrigger asChild>
                  <Button className="bg-blue-600 hover:bg-blue-700">
                    <Plus className="w-4 h-4 mr-2" />
                    New Article
                  </Button>
                </DialogTrigger>
                <DialogContent className="bg-slate-800 border-slate-700 max-w-2xl">
                  <DialogHeader>
                    <DialogTitle className="text-white">Create News Article</DialogTitle>
                  </DialogHeader>
                  <form
                    onSubmit={(e: React.FormEvent<HTMLFormElement>) => {
                      e.preventDefault();
                      const formData = new FormData(e.currentTarget);
                      createNewsMutation.mutate({
                        title: formData.get("title") as string,
                        content: formData.get("content") as string,
                        category: (formData.get("category") as string) || undefined,
                      });
                    }}
                    className="space-y-4"
                  >
                    <div>
                      <Label className="text-slate-200">Title</Label>
                      <Input
                        name="title"
                        className="bg-slate-700 border-slate-600 text-white"
                        placeholder="Article title"
                        required
                      />
                    </div>

                    <div>
                      <Label className="text-slate-200">Category</Label>
                      <Input
                        name="category"
                        className="bg-slate-700 border-slate-600 text-white"
                        placeholder="e.g., Regulations, Technology, Market"
                      />
                    </div>

                    <div>
                      <Label className="text-slate-200">Source</Label>
                      <Input
                        name="source"
                        className="bg-slate-700 border-slate-600 text-white"
                        placeholder="News source"
                      />
                    </div>

                    <div>
                      <Label className="text-slate-200">Content</Label>
                      <Textarea
                        name="content"
                        className="bg-slate-700 border-slate-600 text-white"
                        placeholder="Article content"
                        rows={6}
                        required
                      />
                    </div>

                    <Button type="submit" className="w-full bg-blue-600 hover:bg-blue-700">
                      Publish Article
                    </Button>
                  </form>
                </DialogContent>
              </Dialog>
            </div>

            {newsQuery.isLoading ? (
              <div className="text-slate-400">Loading news...</div>
            ) : (newsQuery.data || []).length > 0 ? (
              <div className="space-y-3">
                {newsQuery.data?.map((article: any) => (
                  <Card key={article.id} className="bg-slate-800/50 border-slate-700 p-4">
                    <div className="flex items-start justify-between mb-2">
                      <h3 className="font-semibold text-white text-lg">{article.title}</h3>
                      {article.category && (
                        <Badge className="bg-blue-900/50 text-blue-200 border-blue-700">
                          {article.category}
                        </Badge>
                      )}
                    </div>
                    <p className="text-slate-300 text-sm mb-2">{article.content}</p>
                    <div className="flex items-center justify-between text-xs text-slate-500">
                      {article.source && <span>Source: {article.source}</span>}
                      <span>{new Date(article.publishedAt).toLocaleDateString()}</span>
                    </div>
                  </Card>
                ))}
              </div>
            ) : (
              <Card className="bg-slate-800/50 border-slate-700 p-6 text-center">
                <p className="text-slate-400">No news articles yet. Click "New Article" to get started.</p>
              </Card>
            )}
          </TabsContent>
        </Tabs>
      </div>
    </DashboardLayout>
  );
}
