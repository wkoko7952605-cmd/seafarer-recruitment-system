import { useAuth } from "@/_core/hooks/useAuth";
import DashboardLayout from "@/components/DashboardLayout";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { AlertCircle, Award, Briefcase, FileText, Plus } from "lucide-react";
import { trpc } from "@/lib/trpc";
import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { toast } from "sonner";

export default function SeafarerDashboard() {
  const { user } = useAuth();
  const [activeTab, setActiveTab] = useState("profile");
  const [isProfileDialogOpen, setIsProfileDialogOpen] = useState(false);

  // Queries
  const profileQuery = trpc.seafarer.getProfile.useQuery();
  const certificatesQuery = trpc.seafarer.getCertificates.useQuery();
  const workExperienceQuery = trpc.seafarer.getWorkExperience.useQuery();
  const applicationsQuery = trpc.seafarer.getApplications.useQuery();
  const jobsQuery = trpc.jobs.list.useQuery();

  // Mutations
  const updateProfileMutation = trpc.seafarer.updateProfile.useMutation({
    onSuccess: () => {
      toast.success("Profile updated successfully!");
      setIsProfileDialogOpen(false);
      profileQuery.refetch();
    },
    onError: (error) => {
      toast.error(error.message || "Failed to update profile");
    },
  });

  const addCertificateMutation = trpc.seafarer.addCertificate.useMutation({
    onSuccess: () => {
      toast.success("Certificate added successfully!");
      certificatesQuery.refetch();
    },
    onError: (error) => {
      toast.error(error.message || "Failed to add certificate");
    },
  });

  const addWorkExperienceMutation = trpc.seafarer.addWorkExperience.useMutation({
    onSuccess: () => {
      toast.success("Work experience added successfully!");
      workExperienceQuery.refetch();
    },
    onError: (error) => {
      toast.error(error.message || "Failed to add work experience");
    },
  });

  const submitApplicationMutation = trpc.jobs.submitApplication.useMutation({
    onSuccess: () => {
      toast.success("Application submitted successfully!");
      applicationsQuery.refetch();
    },
    onError: (error) => {
      toast.error(error.message || "Failed to submit application");
    },
  });

  // Get expiring certificates
  const expiringCertificates = (certificatesQuery.data || []).filter((cert) => {
    const expiryDate = new Date(cert.expiryDate);
    const today = new Date();
    const daysUntilExpiry = Math.floor((expiryDate.getTime() - today.getTime()) / (1000 * 60 * 60 * 24));
    return daysUntilExpiry <= 90 && daysUntilExpiry > 0;
  });

  return (
    <DashboardLayout>
      <div className="space-y-6">
        {/* Header */}
        <div>
          <h1 className="text-3xl font-bold text-white">Welcome, {user?.name}!</h1>
          <p className="text-slate-400 mt-2">Manage your profile and explore job opportunities</p>
        </div>

        {/* Alerts */}
        {expiringCertificates.length > 0 && (
          <Card className="bg-amber-900/20 border-amber-700/50 p-4 flex items-start gap-3">
            <AlertCircle className="w-5 h-5 text-amber-500 mt-0.5 flex-shrink-0" />
            <div>
              <h3 className="font-semibold text-amber-100">Certificates Expiring Soon</h3>
              <p className="text-sm text-amber-200">
                {expiringCertificates.length} certificate(s) will expire within 90 days. Please renew them.
              </p>
            </div>
          </Card>
        )}

        {/* Main Tabs */}
        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <TabsList className="bg-slate-800 border border-slate-700">
            <TabsTrigger value="profile" className="data-[state=active]:bg-blue-600">
              Profile
            </TabsTrigger>
            <TabsTrigger value="certificates" className="data-[state=active]:bg-blue-600">
              Certificates
            </TabsTrigger>
            <TabsTrigger value="experience" className="data-[state=active]:bg-blue-600">
              Experience
            </TabsTrigger>
            <TabsTrigger value="applications" className="data-[state=active]:bg-blue-600">
              Applications
            </TabsTrigger>
            <TabsTrigger value="jobs" className="data-[state=active]:bg-blue-600">
              Job Opportunities
            </TabsTrigger>
          </TabsList>

          {/* Profile Tab */}
          <TabsContent value="profile" className="space-y-4">
            <div className="flex justify-between items-center">
              <h2 className="text-2xl font-bold text-white">Professional Profile</h2>
              <Dialog open={isProfileDialogOpen} onOpenChange={setIsProfileDialogOpen}>
                <DialogTrigger asChild>
                  <Button className="bg-blue-600 hover:bg-blue-700">Edit Profile</Button>
                </DialogTrigger>
                <DialogContent className="bg-slate-800 border-slate-700">
                  <DialogHeader>
                    <DialogTitle className="text-white">Edit Your Profile</DialogTitle>
                  </DialogHeader>
                  <form
                    onSubmit={(e) => {
                      e.preventDefault();
                      const formData = new FormData(e.currentTarget);
                      updateProfileMutation.mutate({
                        firstName: formData.get("firstName") as string,
                        lastName: formData.get("lastName") as string,
                        rank: formData.get("rank") as string,
                        yearsOfExperience: parseInt(formData.get("yearsOfExperience") as string) || 0,
                        nationality: formData.get("nationality") as string,
                        bio: formData.get("bio") as string,
                      });
                    }}
                    className="space-y-4"
                  >
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <Label className="text-slate-200">First Name</Label>
                        <Input
                          name="firstName"
                          defaultValue={profileQuery.data?.firstName || ""}
                          className="bg-slate-700 border-slate-600 text-white"
                        />
                      </div>
                      <div>
                        <Label className="text-slate-200">Last Name</Label>
                        <Input
                          name="lastName"
                          defaultValue={profileQuery.data?.lastName || ""}
                          className="bg-slate-700 border-slate-600 text-white"
                        />
                      </div>
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <Label className="text-slate-200">Rank</Label>
                        <Input
                          name="rank"
                          defaultValue={profileQuery.data?.rank || ""}
                          className="bg-slate-700 border-slate-600 text-white"
                        />
                      </div>
                      <div>
                        <Label className="text-slate-200">Years of Experience</Label>
                        <Input
                          name="yearsOfExperience"
                          type="number"
                          defaultValue={profileQuery.data?.yearsOfExperience || 0}
                          className="bg-slate-700 border-slate-600 text-white"
                        />
                      </div>
                    </div>
                    <div>
                      <Label className="text-slate-200">Nationality</Label>
                      <Input
                        name="nationality"
                        defaultValue={profileQuery.data?.nationality || ""}
                        className="bg-slate-700 border-slate-600 text-white"
                      />
                    </div>
                    <div>
                      <Label className="text-slate-200">Bio</Label>
                      <Textarea
                        name="bio"
                        defaultValue={profileQuery.data?.bio || ""}
                        className="bg-slate-700 border-slate-600 text-white"
                        rows={4}
                      />
                    </div>
                    <Button type="submit" className="w-full bg-blue-600 hover:bg-blue-700">
                      Save Changes
                    </Button>
                  </form>
                </DialogContent>
              </Dialog>
            </div>

            {profileQuery.isLoading ? (
              <div className="text-slate-400">Loading profile...</div>
            ) : profileQuery.data ? (
              <Card className="bg-slate-800/50 border-slate-700 p-6">
                <div className="grid md:grid-cols-2 gap-6">
                  <div>
                    <p className="text-slate-400 text-sm">Full Name</p>
                    <p className="text-white text-lg font-semibold">
                      {profileQuery.data.firstName} {profileQuery.data.lastName}
                    </p>
                  </div>
                  <div>
                    <p className="text-slate-400 text-sm">Rank</p>
                    <p className="text-white text-lg font-semibold">{profileQuery.data.rank || "Not specified"}</p>
                  </div>
                  <div>
                    <p className="text-slate-400 text-sm">Years of Experience</p>
                    <p className="text-white text-lg font-semibold">{profileQuery.data.yearsOfExperience || 0} years</p>
                  </div>
                  <div>
                    <p className="text-slate-400 text-sm">Nationality</p>
                    <p className="text-white text-lg font-semibold">{profileQuery.data.nationality || "Not specified"}</p>
                  </div>
                </div>
                {profileQuery.data.bio && (
                  <div className="mt-6 pt-6 border-t border-slate-700">
                    <p className="text-slate-400 text-sm">Bio</p>
                    <p className="text-slate-200 mt-2">{profileQuery.data.bio}</p>
                  </div>
                )}
              </Card>
            ) : (
              <Card className="bg-slate-800/50 border-slate-700 p-6 text-center">
                <p className="text-slate-400">No profile created yet. Click "Edit Profile" to get started.</p>
              </Card>
            )}
          </TabsContent>

          {/* Certificates Tab */}
          <TabsContent value="certificates" className="space-y-4">
            <div className="flex justify-between items-center">
              <h2 className="text-2xl font-bold text-white">Certificates & Licenses</h2>
              <Dialog>
                <DialogTrigger asChild>
                  <Button className="bg-blue-600 hover:bg-blue-700">
                    <Plus className="w-4 h-4 mr-2" />
                    Add Certificate
                  </Button>
                </DialogTrigger>
                <DialogContent className="bg-slate-800 border-slate-700">
                  <DialogHeader>
                    <DialogTitle className="text-white">Add Certificate</DialogTitle>
                  </DialogHeader>
                  <form
                    onSubmit={(e) => {
                      e.preventDefault();
                      const formData = new FormData(e.currentTarget);
                      addCertificateMutation.mutate({
                        certificateType: formData.get("certificateType") as string,
                        certificateNumber: formData.get("certificateNumber") as string,
                        issuedDate: formData.get("issuedDate") as string,
                        expiryDate: formData.get("expiryDate") as string,
                        issuingCountry: formData.get("issuingCountry") as string,
                      });
                    }}
                    className="space-y-4"
                  >
                    <div>
                      <Label className="text-slate-200">Certificate Type</Label>
                      <Input
                        name="certificateType"
                        placeholder="e.g., CDC, STCW, GMDSS"
                        className="bg-slate-700 border-slate-600 text-white"
                        required
                      />
                    </div>
                    <div>
                      <Label className="text-slate-200">Certificate Number</Label>
                      <Input
                        name="certificateNumber"
                        className="bg-slate-700 border-slate-600 text-white"
                      />
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <Label className="text-slate-200">Issued Date</Label>
                        <Input
                          name="issuedDate"
                          type="date"
                          className="bg-slate-700 border-slate-600 text-white"
                        />
                      </div>
                      <div>
                        <Label className="text-slate-200">Expiry Date</Label>
                        <Input
                          name="expiryDate"
                          type="date"
                          className="bg-slate-700 border-slate-600 text-white"
                          required
                        />
                      </div>
                    </div>
                    <div>
                      <Label className="text-slate-200">Issuing Country</Label>
                      <Input
                        name="issuingCountry"
                        className="bg-slate-700 border-slate-600 text-white"
                      />
                    </div>
                    <Button type="submit" className="w-full bg-blue-600 hover:bg-blue-700">
                      Add Certificate
                    </Button>
                  </form>
                </DialogContent>
              </Dialog>
            </div>

            {certificatesQuery.isLoading ? (
              <div className="text-slate-400">Loading certificates...</div>
            ) : (certificatesQuery.data || []).length > 0 ? (
              <div className="space-y-3">
                {certificatesQuery.data?.map((cert) => {
                  const expiryDate = new Date(cert.expiryDate);
                  const today = new Date();
                  const daysUntilExpiry = Math.floor((expiryDate.getTime() - today.getTime()) / (1000 * 60 * 60 * 24));
                  const isExpired = daysUntilExpiry < 0;
                  const isExpiringSoon = daysUntilExpiry <= 90 && daysUntilExpiry > 0;

                  return (
                    <Card key={cert.id} className="bg-slate-800/50 border-slate-700 p-4">
                      <div className="flex items-start justify-between">
                        <div className="flex items-start gap-3">
                          <Award className="w-5 h-5 text-blue-400 mt-1" />
                          <div>
                            <h3 className="font-semibold text-white">{cert.certificateType}</h3>
                            {cert.certificateNumber && (
                              <p className="text-sm text-slate-400">#{cert.certificateNumber}</p>
                            )}
                            <p className="text-sm text-slate-400 mt-1">
                              Expires: {expiryDate.toLocaleDateString()}
                            </p>
                          </div>
                        </div>
                        <div>
                          {isExpired ? (
                            <Badge className="bg-red-900/50 text-red-200 border-red-700">Expired</Badge>
                          ) : isExpiringSoon ? (
                            <Badge className="bg-amber-900/50 text-amber-200 border-amber-700">Expiring Soon</Badge>
                          ) : (
                            <Badge className="bg-green-900/50 text-green-200 border-green-700">Valid</Badge>
                          )}
                        </div>
                      </div>
                    </Card>
                  );
                })}
              </div>
            ) : (
              <Card className="bg-slate-800/50 border-slate-700 p-6 text-center">
                <p className="text-slate-400">No certificates added yet. Click "Add Certificate" to get started.</p>
              </Card>
            )}
          </TabsContent>

          {/* Experience Tab */}
          <TabsContent value="experience" className="space-y-4">
            <div className="flex justify-between items-center">
              <h2 className="text-2xl font-bold text-white">Work Experience</h2>
              <Dialog>
                <DialogTrigger asChild>
                  <Button className="bg-blue-600 hover:bg-blue-700">
                    <Plus className="w-4 h-4 mr-2" />
                    Add Experience
                  </Button>
                </DialogTrigger>
                <DialogContent className="bg-slate-800 border-slate-700">
                  <DialogHeader>
                    <DialogTitle className="text-white">Add Work Experience</DialogTitle>
                  </DialogHeader>
                  <form
                    onSubmit={(e) => {
                      e.preventDefault();
                      const formData = new FormData(e.currentTarget);
                      addWorkExperienceMutation.mutate({
                        companyName: formData.get("companyName") as string,
                        position: formData.get("position") as string,
                        shipType: formData.get("shipType") as string,
                        startDate: formData.get("startDate") as string,
                        endDate: formData.get("endDate") as string,
                        description: formData.get("description") as string,
                      });
                    }}
                    className="space-y-4"
                  >
                    <div>
                      <Label className="text-slate-200">Company Name</Label>
                      <Input
                        name="companyName"
                        className="bg-slate-700 border-slate-600 text-white"
                        required
                      />
                    </div>
                    <div>
                      <Label className="text-slate-200">Position</Label>
                      <Input
                        name="position"
                        className="bg-slate-700 border-slate-600 text-white"
                        required
                      />
                    </div>
                    <div>
                      <Label className="text-slate-200">Ship Type</Label>
                      <Input
                        name="shipType"
                        placeholder="e.g., Container Ship, Tanker"
                        className="bg-slate-700 border-slate-600 text-white"
                      />
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <Label className="text-slate-200">Start Date</Label>
                        <Input
                          name="startDate"
                          type="date"
                          className="bg-slate-700 border-slate-600 text-white"
                          required
                        />
                      </div>
                      <div>
                        <Label className="text-slate-200">End Date</Label>
                        <Input
                          name="endDate"
                          type="date"
                          className="bg-slate-700 border-slate-600 text-white"
                        />
                      </div>
                    </div>
                    <div>
                      <Label className="text-slate-200">Description</Label>
                      <Textarea
                        name="description"
                        className="bg-slate-700 border-slate-600 text-white"
                        rows={3}
                      />
                    </div>
                    <Button type="submit" className="w-full bg-blue-600 hover:bg-blue-700">
                      Add Experience
                    </Button>
                  </form>
                </DialogContent>
              </Dialog>
            </div>

            {workExperienceQuery.isLoading ? (
              <div className="text-slate-400">Loading experience...</div>
            ) : (workExperienceQuery.data || []).length > 0 ? (
              <div className="space-y-3">
                {workExperienceQuery.data?.map((exp) => (
                  <Card key={exp.id} className="bg-slate-800/50 border-slate-700 p-4">
                    <div className="flex items-start gap-3">
                      <Briefcase className="w-5 h-5 text-green-400 mt-1" />
                      <div className="flex-1">
                        <h3 className="font-semibold text-white">{exp.position}</h3>
                        <p className="text-sm text-slate-400">{exp.companyName}</p>
                        {exp.shipType && (
                          <p className="text-sm text-slate-400">Ship Type: {exp.shipType}</p>
                        )}
                        <p className="text-xs text-slate-500 mt-2">
                          {new Date(exp.startDate).toLocaleDateString()} -{" "}
                          {exp.endDate ? new Date(exp.endDate).toLocaleDateString() : "Present"}
                        </p>
                        {exp.description && (
                          <p className="text-sm text-slate-300 mt-2">{exp.description}</p>
                        )}
                      </div>
                    </div>
                  </Card>
                ))}
              </div>
            ) : (
              <Card className="bg-slate-800/50 border-slate-700 p-6 text-center">
                <p className="text-slate-400">No work experience added yet. Click "Add Experience" to get started.</p>
              </Card>
            )}
          </TabsContent>

          {/* Applications Tab */}
          <TabsContent value="applications" className="space-y-4">
            <h2 className="text-2xl font-bold text-white">My Applications</h2>
            {applicationsQuery.isLoading ? (
              <div className="text-slate-400">Loading applications...</div>
            ) : (applicationsQuery.data || []).length > 0 ? (
              <div className="space-y-3">
                {applicationsQuery.data?.map((app) => (
                  <Card key={app.id} className="bg-slate-800/50 border-slate-700 p-4">
                    <div className="flex items-start justify-between">
                      <div>
                        <h3 className="font-semibold text-white">Job ID: {app.jobId}</h3>
                        <p className="text-sm text-slate-400">Applied: {new Date(app.appliedAt).toLocaleDateString()}</p>
                      </div>
                      <Badge
                        className={
                          app.status === "accepted"
                            ? "bg-green-900/50 text-green-200 border-green-700"
                            : app.status === "rejected"
                              ? "bg-red-900/50 text-red-200 border-red-700"
                              : "bg-blue-900/50 text-blue-200 border-blue-700"
                        }
                      >
                        {app.status}
                      </Badge>
                    </div>
                  </Card>
                ))}
              </div>
            ) : (
              <Card className="bg-slate-800/50 border-slate-700 p-6 text-center">
                <p className="text-slate-400">No applications yet. Browse job opportunities to apply.</p>
              </Card>
            )}
          </TabsContent>

          {/* Jobs Tab */}
          <TabsContent value="jobs" className="space-y-4">
            <h2 className="text-2xl font-bold text-white">Available Jobs</h2>
            {jobsQuery.isLoading ? (
              <div className="text-slate-400">Loading jobs...</div>
            ) : (jobsQuery.data || []).length > 0 ? (
              <div className="space-y-3">
                {jobsQuery.data?.map((job) => {
                  const hasApplied = (applicationsQuery.data || []).some((app) => app.jobId === job.id);
                  return (
                    <Card key={job.id} className="bg-slate-800/50 border-slate-700 p-4">
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <h3 className="font-semibold text-white text-lg">{job.title}</h3>
                          <p className="text-sm text-slate-400">{job.shipType}</p>
                          <p className="text-sm text-slate-300 mt-2">{job.description}</p>
                          {job.salary && (
                            <p className="text-sm text-green-400 mt-2">Salary: {job.salary}</p>
                          )}
                        </div>
                        <Button
                          onClick={() => submitApplicationMutation.mutate({ jobId: job.id })}
                          disabled={hasApplied || submitApplicationMutation.isPending}
                          className={
                            hasApplied
                              ? "bg-slate-600 cursor-not-allowed"
                              : "bg-blue-600 hover:bg-blue-700"
                          }
                        >
                          {hasApplied ? "Applied" : "Apply"}
                        </Button>
                      </div>
                    </Card>
                  );
                })}
              </div>
            ) : (
              <Card className="bg-slate-800/50 border-slate-700 p-6 text-center">
                <p className="text-slate-400">No jobs available at the moment. Check back soon!</p>
              </Card>
            )}
          </TabsContent>
        </Tabs>
      </div>
    </DashboardLayout>
  );
}
