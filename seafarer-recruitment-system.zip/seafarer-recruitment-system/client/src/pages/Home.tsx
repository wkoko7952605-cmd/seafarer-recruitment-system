import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Anchor, Briefcase, Users, Award, TrendingUp, Shield } from "lucide-react";
import { getLoginUrl } from "@/const";
import { useLocation } from "wouter";
import { useEffect } from "react";

export default function Home() {
  const { user, loading, isAuthenticated } = useAuth();
  const [, navigate] = useLocation();

  // Redirect authenticated users to their dashboard
  useEffect(() => {
    if (isAuthenticated && user) {
      if (user.role === "seafarer") {
        navigate("/seafarer/dashboard");
      } else if (user.role === "employer") {
        navigate("/employer/dashboard");
      } else if (user.role === "admin") {
        navigate("/admin/dashboard");
      }
    }
  }, [isAuthenticated, user, navigate]);

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-slate-900 to-slate-800">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-500"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900">
      {/* Navigation */}
      <nav className="border-b border-slate-700 bg-slate-900/50 backdrop-blur-sm sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Anchor className="w-8 h-8 text-blue-500" />
            <span className="text-xl font-bold text-white">Maritime Crew Hub</span>
          </div>
          <div className="flex gap-4">
            <Button
              variant="outline"
              onClick={() => (window.location.href = getLoginUrl())}
              className="border-slate-600 text-slate-200 hover:bg-slate-800"
            >
              Sign In
            </Button>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-24">
        <div className="grid md:grid-cols-2 gap-12 items-center">
          <div>
            <h1 className="text-5xl md:text-6xl font-bold text-white mb-6 leading-tight">
              Connect Global Maritime Talent
            </h1>
            <p className="text-xl text-slate-300 mb-8 leading-relaxed">
              The premier platform connecting seafarers with world-class shipping companies. Manage profiles, track certifications, and discover opportunities in the maritime industry.
            </p>
            <div className="flex gap-4">
              <Button
                size="lg"
                onClick={() => (window.location.href = getLoginUrl())}
                className="bg-blue-600 hover:bg-blue-700 text-white px-8"
              >
                Get Started
              </Button>
              <Button
                size="lg"
                variant="outline"
                className="border-slate-400 text-slate-200 hover:bg-slate-800 px-8"
              >
                Learn More
              </Button>
            </div>
          </div>
          <div className="relative">
            <div className="absolute inset-0 bg-gradient-to-r from-blue-500/20 to-purple-500/20 rounded-lg blur-3xl"></div>
            <div className="relative bg-slate-800/50 border border-slate-700 rounded-lg p-8 backdrop-blur-sm">
              <div className="space-y-4">
                <div className="flex items-center gap-3 p-4 bg-slate-700/50 rounded-lg">
                  <Award className="w-6 h-6 text-blue-400" />
                  <span className="text-slate-200">Verified Certifications</span>
                </div>
                <div className="flex items-center gap-3 p-4 bg-slate-700/50 rounded-lg">
                  <TrendingUp className="w-6 h-6 text-green-400" />
                  <span className="text-slate-200">Career Growth</span>
                </div>
                <div className="flex items-center gap-3 p-4 bg-slate-700/50 rounded-lg">
                  <Shield className="w-6 h-6 text-purple-400" />
                  <span className="text-slate-200">Secure & Trusted</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20 border-t border-slate-700">
        <h2 className="text-4xl font-bold text-white mb-16 text-center">
          Designed for Maritime Professionals
        </h2>
        <div className="grid md:grid-cols-3 gap-8">
          {/* Seafarers */}
          <Card className="bg-slate-800/50 border-slate-700 hover:border-blue-500/50 transition-colors p-8">
            <Users className="w-12 h-12 text-blue-500 mb-4" />
            <h3 className="text-xl font-bold text-white mb-3">For Seafarers</h3>
            <p className="text-slate-300 mb-6">
              Build your professional profile, manage certifications, and discover exciting job opportunities with leading shipping companies worldwide.
            </p>
            <ul className="space-y-2 text-sm text-slate-400">
              <li>✓ Complete profile management</li>
              <li>✓ Certificate tracking & alerts</li>
              <li>✓ Job applications</li>
              <li>✓ Career insights</li>
            </ul>
          </Card>

          {/* Employers */}
          <Card className="bg-slate-800/50 border-slate-700 hover:border-green-500/50 transition-colors p-8">
            <Briefcase className="w-12 h-12 text-green-500 mb-4" />
            <h3 className="text-xl font-bold text-white mb-3">For Employers</h3>
            <p className="text-slate-300 mb-6">
              Post crew requirements, review qualified candidates, and build your team with verified maritime professionals.
            </p>
            <ul className="space-y-2 text-sm text-slate-400">
              <li>✓ Crew request posting</li>
              <li>✓ Candidate screening</li>
              <li>✓ Verified profiles</li>
              <li>✓ Hiring management</li>
            </ul>
          </Card>

          {/* Admins */}
          <Card className="bg-slate-800/50 border-slate-700 hover:border-purple-500/50 transition-colors p-8">
            <Shield className="w-12 h-12 text-purple-500 mb-4" />
            <h3 className="text-xl font-bold text-white mb-3">For Administrators</h3>
            <p className="text-slate-300 mb-6">
              Manage the platform, oversee all activities, maintain industry standards, and keep the community secure.
            </p>
            <ul className="space-y-2 text-sm text-slate-400">
              <li>✓ Full platform control</li>
              <li>✓ User management</li>
              <li>✓ Content moderation</li>
              <li>✓ Analytics & reports</li>
            </ul>
          </Card>
        </div>
      </section>

      {/* CTA Section */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
        <div className="bg-gradient-to-r from-blue-600 to-blue-700 rounded-lg p-12 text-center">
          <h2 className="text-3xl font-bold text-white mb-4">
            Ready to Join the Maritime Community?
          </h2>
          <p className="text-blue-100 mb-8 text-lg">
            Sign in to access your dashboard and start connecting with opportunities.
          </p>
          <Button
            size="lg"
            onClick={() => (window.location.href = getLoginUrl())}
            className="bg-white text-blue-600 hover:bg-blue-50 px-8 font-semibold"
          >
            Sign In Now
          </Button>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-slate-700 bg-slate-900/50 mt-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 text-center text-slate-400">
          <p>© 2026 Maritime Crew Hub. All rights reserved. | Contact: {" "}
            <a href="mailto:wkoko.crew@wkokosejin-mm.com" className="text-blue-400 hover:text-blue-300">
              wkoko.crew@wkokosejin-mm.com
            </a>
          </p>
        </div>
      </footer>
    </div>
  );
}
