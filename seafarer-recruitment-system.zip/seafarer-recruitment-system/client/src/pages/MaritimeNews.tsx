import { useEffect, useState } from "react";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Skeleton } from "@/components/ui/skeleton";
import { Newspaper, Search, Calendar, User } from "lucide-react";
import { useLocation } from "wouter";

export default function MaritimeNews() {
  const [, navigate] = useLocation();
  const [searchTerm, setSearchTerm] = useState("");
  const { data: news, isLoading } = trpc.public.getNews.useQuery();

  const filteredNews = news?.filter((item) =>
    item.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
    item.content.toLowerCase().includes(searchTerm.toLowerCase())
  ) || [];

  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-900 via-slate-800 to-slate-900">
      {/* Header */}
      <div className="border-b border-slate-700 bg-slate-900/50 backdrop-blur-sm sticky top-0 z-40">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Newspaper className="w-8 h-8 text-blue-400" />
            <h1 className="text-2xl font-bold text-white">Maritime News</h1>
          </div>
          <Button
            variant="outline"
            onClick={() => navigate("/")}
            className="border-slate-600 text-slate-300 hover:bg-slate-800"
          >
            Back to Home
          </Button>
        </div>
      </div>

      {/* Main Content */}
      <div className="container mx-auto px-4 py-12">
        {/* Search Bar */}
        <div className="mb-8">
          <div className="relative">
            <Search className="absolute left-3 top-3 w-5 h-5 text-slate-400" />
            <Input
              placeholder="Search news articles..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10 bg-slate-800 border-slate-700 text-white placeholder:text-slate-400"
            />
          </div>
        </div>

        {/* News Grid */}
        {isLoading ? (
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[...Array(6)].map((_, i) => (
              <Card key={i} className="bg-slate-800 border-slate-700 p-6">
                <Skeleton className="h-6 w-3/4 mb-4 bg-slate-700" />
                <Skeleton className="h-4 w-full mb-2 bg-slate-700" />
                <Skeleton className="h-4 w-5/6 mb-4 bg-slate-700" />
                <Skeleton className="h-10 w-24 bg-slate-700" />
              </Card>
            ))}
          </div>
        ) : filteredNews.length === 0 ? (
          <div className="text-center py-12">
            <Newspaper className="w-16 h-16 text-slate-600 mx-auto mb-4" />
            <p className="text-slate-400 text-lg">
              {searchTerm ? "No articles found matching your search." : "No news articles available yet."}
            </p>
          </div>
        ) : (
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredNews.map((article) => (
              <Card
                key={article.id}
                className="bg-slate-800 border-slate-700 hover:border-blue-500 transition-colors overflow-hidden group cursor-pointer"
              >
                <div className="p-6 flex flex-col h-full">
                  {/* Title */}
                  <h3 className="text-lg font-semibold text-white mb-2 group-hover:text-blue-400 transition-colors line-clamp-2">
                    {article.title}
                  </h3>

                  {/* Content Preview */}
                  <p className="text-slate-300 text-sm mb-4 line-clamp-3 flex-grow">
                    {article.content}
                  </p>

                  {/* Meta Information */}
                  <div className="space-y-2 text-xs text-slate-400 border-t border-slate-700 pt-4">
                    <div className="flex items-center gap-2">
                      <Calendar className="w-4 h-4" />
                      <span>{article.publishedAt ? new Date(article.publishedAt).toLocaleDateString() : new Date(article.createdAt).toLocaleDateString()}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <User className="w-4 h-4" />
                      <span>Maritime Team</span>
                    </div>
                  </div>

                  {/* Read More Button */}
                  <Button
                    variant="ghost"
                    className="mt-4 w-full text-blue-400 hover:text-blue-300 hover:bg-slate-700/50"
                  >
                    Read More →
                  </Button>
                </div>
              </Card>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
