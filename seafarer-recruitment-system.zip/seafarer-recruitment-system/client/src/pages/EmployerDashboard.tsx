import { useAuth } from "@/_core/hooks/useAuth";
import DashboardLayout from "@/components/DashboardLayout";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Briefcase, Plus, Users, TrendingUp, AlertCircle } from "lucide-react";
import { trpc } from "@/lib/trpc";
import { useState } from "react";
import { toast } from "sonner";

export default function EmployerDashboard() {
  const { user } = useAuth();
  const [activeTab, setActiveTab] = useState("profile");
  const [isProfileDialogOpen, setIsProfileDialogOpen] = useState(false);
  const [isCrewRequestDialogOpen, setIsCrewRequestDialogOpen] = useState(false);

  // Queries
  const profileQuery = trpc.employer.getProfile.useQuery();
  const crewRequestsQuery = trpc.employer.getCrewRequests.useQuery();
  const applicationsQuery = trpc.employer.getApplications.useQuery();

  // Mutations
  const updateProfileMutation = trpc.employer.updateProfile.useMutation({
    onSuccess: () => {
      toast.success("Company profile updated successfully!");
      setIsProfileDialogOpen(false);
      profileQuery.refetch();
    },
    onError: (error) => {
      toast.error(error.message || "Failed to update profile");
    },
  });

  const submitCrewRequestMutation = trpc.employer.submitCrewRequest.useMutation({
    onSuccess: () => {
      toast.success("Crew request submitted successfully!");
      setIsCrewRequestDialogOpen(false);
      crewRequestsQuery.refetch();
    },
    onError: (error) => {
      toast.error(error.message || "Failed to submit crew request");
    },
  });

  const reviewApplicationMutation = trpc.employer.reviewApplication.useMutation({
    onSuccess: () => {
      toast.success("Application reviewed!");
      applicationsQuery.refetch();
    },
    onError: (error) => {
      toast.error(error.message || "Failed to review application");
    },
  });

  // Get pending crew requests
  const pendingRequests = (crewRequestsQuery.data || []).filter((req: any) => req.status === "pending");

  // Get pending applications
  const pendingApplications = (applicationsQuery.data || []).filter((app: any) => app.status === "pending");

  return (
    <DashboardLayout>
      <div className="space-y-6">
        {/* Header */}
        <div>
          <h1 className="text-3xl font-bold text-white">Employer Dashboard</h1>
          <p className="text-slate-400 mt-2">Manage crew requirements and find qualified seafarers</p>
        </div>

        {/* Alerts */}
        {pendingApplications.length > 0 && (
          <Card className="bg-blue-900/20 border-blue-700/50 p-4 flex items-start gap-3">
            <AlertCircle className="w-5 h-5 text-blue-500 mt-0.5 flex-shrink-0" />
            <div>
              <h3 className="font-semibold text-blue-100">Pending Applications</h3>
              <p className="text-sm text-blue-200">
                You have {pendingApplications.length} application(s) awaiting review.
              </p>
            </div>
          </Card>
        )}

        {/* Stats */}
        <div className="grid md:grid-cols-3 gap-4">
          <Card className="bg-slate-800/50 border-slate-700 p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-slate-400 text-sm">Total Crew Requests</p>
                <p className="text-3xl font-bold text-white mt-2">{crewRequestsQuery.data?.length || 0}</p>
              </div>
              <Briefcase className="w-10 h-10 text-blue-500 opacity-50" />
            </div>
          </Card>

          <Card className="bg-slate-800/50 border-slate-700 p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-slate-400 text-sm">Pending Applications</p>
                <p className="text-3xl font-bold text-white mt-2">{pendingApplications.length}</p>
              </div>
              <Users className="w-10 h-10 text-green-500 opacity-50" />
            </div>
          </Card>

          <Card className="bg-slate-800/50 border-slate-700 p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-slate-400 text-sm">Active Crew Requests</p>
                <p className="text-3xl font-bold text-white mt-2">{pendingRequests.length}</p>
              </div>
              <TrendingUp className="w-10 h-10 text-purple-500 opacity-50" />
            </div>
          </Card>
        </div>

        {/* Main Tabs */}
        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <TabsList className="bg-slate-800 border border-slate-700">
            <TabsTrigger value="profile" className="data-[state=active]:bg-blue-600">
              Company Profile
            </TabsTrigger>
            <TabsTrigger value="crew-requests" className="data-[state=active]:bg-blue-600">
              Crew Requests
            </TabsTrigger>
            <TabsTrigger value="applications" className="data-[state=active]:bg-blue-600">
              Applications
            </TabsTrigger>
          </TabsList>

          {/* Profile Tab */}
          <TabsContent value="profile" className="space-y-4">
            <div className="flex justify-between items-center">
              <h2 className="text-2xl font-bold text-white">Company Information</h2>
              <Dialog open={isProfileDialogOpen} onOpenChange={setIsProfileDialogOpen}>
                <DialogTrigger asChild>
                  <Button className="bg-blue-600 hover:bg-blue-700">Edit Profile</Button>
                </DialogTrigger>
                <DialogContent className="bg-slate-800 border-slate-700">
                  <DialogHeader>
                    <DialogTitle className="text-white">Edit Company Profile</DialogTitle>
                  </DialogHeader>
                  <form
                    onSubmit={(e: React.FormEvent<HTMLFormElement>) => {
                      e.preventDefault();
                      const formData = new FormData(e.currentTarget);
                      updateProfileMutation.mutate({
                        companyName: formData.get("companyName") as string,
                        industry: formData.get("industry") as string,
                        country: formData.get("country") as string,
                        contactPhone: formData.get("contactPhone") as string,
                        companyDescription: formData.get("companyDescription") as string,
                      });
                    }}
                    className="space-y-4"
                  >
                    <div>
                      <Label className="text-slate-200">Company Name</Label>
                      <Input
                        name="companyName"
                        defaultValue={profileQuery.data?.companyName || ""}
                        className="bg-slate-700 border-slate-600 text-white"
                        required
                      />
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <Label className="text-slate-200">Industry</Label>
                        <Input
                          name="industry"
                          defaultValue={profileQuery.data?.industry || ""}
                          className="bg-slate-700 border-slate-600 text-white"
                        />
                      </div>
                      <div>
                        <Label className="text-slate-200">Country</Label>
                        <Input
                          name="country"
                          defaultValue={profileQuery.data?.country || ""}
                          className="bg-slate-700 border-slate-600 text-white"
                        />
                      </div>
                    </div>
                    <div>
                      <Label className="text-slate-200">Contact Phone</Label>
                      <Input
                        name="contactPhone"
                        type="tel"
                        defaultValue={profileQuery.data?.contactPhone || ""}
                        className="bg-slate-700 border-slate-600 text-white"
                      />
                    </div>
                    <div>
                      <Label className="text-slate-200">Company Description</Label>
                      <Textarea
                        name="companyDescription"
                        defaultValue={profileQuery.data?.companyDescription || ""}
                        className="bg-slate-700 border-slate-600 text-white"
                        rows={4}
                      />
                    </div>
                    <Button type="submit" className="w-full bg-blue-600 hover:bg-blue-700">
                      Save Changes
                    </Button>
                  </form>
                </DialogContent>
              </Dialog>
            </div>

            {profileQuery.isLoading ? (
              <div className="text-slate-400">Loading profile...</div>
            ) : profileQuery.data ? (
              <Card className="bg-slate-800/50 border-slate-700 p-6">
                <div className="grid md:grid-cols-2 gap-6">
                  <div>
                    <p className="text-slate-400 text-sm">Company Name</p>
                    <p className="text-white text-lg font-semibold">{profileQuery.data.companyName}</p>
                  </div>
                  <div>
                    <p className="text-slate-400 text-sm">Industry</p>
                    <p className="text-white text-lg font-semibold">{profileQuery.data.industry || "Not specified"}</p>
                  </div>
                  <div>
                    <p className="text-slate-400 text-sm">Country</p>
                    <p className="text-white text-lg font-semibold">{profileQuery.data.country || "Not specified"}</p>
                  </div>
                  {profileQuery.data.contactPhone && (
                    <div>
                      <p className="text-slate-400 text-sm">Contact Phone</p>
                      <p className="text-white text-lg font-semibold">{profileQuery.data.contactPhone}</p>
                    </div>
                  )}
                </div>
                {profileQuery.data.companyDescription && (
                  <div className="mt-6 pt-6 border-t border-slate-700">
                    <p className="text-slate-400 text-sm">Company Description</p>
                    <p className="text-slate-200 mt-2">{profileQuery.data.companyDescription}</p>
                  </div>
                )}
              </Card>
            ) : (
              <Card className="bg-slate-800/50 border-slate-700 p-6 text-center">
                <p className="text-slate-400">No company profile created yet. Click "Edit Profile" to get started.</p>
              </Card>
            )}
          </TabsContent>

          {/* Crew Requests Tab */}
          <TabsContent value="crew-requests" className="space-y-4">
            <div className="flex justify-between items-center">
              <h2 className="text-2xl font-bold text-white">Crew Requests</h2>
              <Dialog open={isCrewRequestDialogOpen} onOpenChange={setIsCrewRequestDialogOpen}>
                <DialogTrigger asChild>
                  <Button className="bg-blue-600 hover:bg-blue-700">
                    <Plus className="w-4 h-4 mr-2" />
                    New Crew Request
                  </Button>
                </DialogTrigger>
                <DialogContent className="bg-slate-800 border-slate-700 max-w-2xl">
                  <DialogHeader>
                    <DialogTitle className="text-white">Submit Crew Request</DialogTitle>
                  </DialogHeader>
                  <form
                    onSubmit={(e: React.FormEvent<HTMLFormElement>) => {
                      e.preventDefault();
                      const formData = new FormData(e.currentTarget);
                      submitCrewRequestMutation.mutate({
                        shipType: formData.get("shipType") as string,
                        requiredPositions: formData.get("requiredPositions") as string,
                        numberOfCrew: parseInt(formData.get("numberOfCrew") as string) || 1,
                        contractDuration: formData.get("contractDuration") as string,
                        salary: formData.get("salary") as string,
                        requirements: formData.get("requirements") as string,
                      });
                    }}
                    className="space-y-4"
                  >
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <Label className="text-slate-200">Ship Type</Label>
                        <Select name="shipType" required>
                          <SelectTrigger className="bg-slate-700 border-slate-600 text-white">
                            <SelectValue placeholder="Select ship type" />
                          </SelectTrigger>
                          <SelectContent className="bg-slate-700 border-slate-600">
                            <SelectItem value="Container Ship">Container Ship</SelectItem>
                            <SelectItem value="Tanker">Tanker</SelectItem>
                            <SelectItem value="Bulk Carrier">Bulk Carrier</SelectItem>
                            <SelectItem value="General Cargo">General Cargo</SelectItem>
                            <SelectItem value="RoRo Ship">RoRo Ship</SelectItem>
                            <SelectItem value="Passenger Ship">Passenger Ship</SelectItem>
                            <SelectItem value="Offshore Vessel">Offshore Vessel</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      <div>
                        <Label className="text-slate-200">Number of Crew</Label>
                        <Input
                          name="numberOfCrew"
                          type="number"
                          min="1"
                          defaultValue="1"
                          className="bg-slate-700 border-slate-600 text-white"
                        />
                      </div>
                    </div>

                    <div>
                      <Label className="text-slate-200">Required Positions</Label>
                      <Textarea
                        name="requiredPositions"
                        placeholder="e.g., Captain, Chief Engineer, Second Officer"
                        className="bg-slate-700 border-slate-600 text-white"
                        rows={2}
                        required
                      />
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <Label className="text-slate-200">Contract Duration</Label>
                        <Input
                          name="contractDuration"
                          placeholder="e.g., 6 months, 1 year"
                          className="bg-slate-700 border-slate-600 text-white"
                        />
                      </div>
                      <div>
                        <Label className="text-slate-200">Salary Range</Label>
                        <Input
                          name="salary"
                          placeholder="e.g., $2000-$3000/month"
                          className="bg-slate-700 border-slate-600 text-white"
                        />
                      </div>
                    </div>

                    <div>
                      <Label className="text-slate-200">Additional Requirements</Label>
                      <Textarea
                        name="requirements"
                        placeholder="Experience, certifications, language skills, etc."
                        className="bg-slate-700 border-slate-600 text-white"
                        rows={3}
                      />
                    </div>

                    <Button type="submit" className="w-full bg-blue-600 hover:bg-blue-700">
                      Submit Request
                    </Button>
                  </form>
                </DialogContent>
              </Dialog>
            </div>

            {crewRequestsQuery.isLoading ? (
              <div className="text-slate-400">Loading crew requests...</div>
            ) : (crewRequestsQuery.data || []).length > 0 ? (
              <div className="space-y-3">
                {crewRequestsQuery.data?.map((request: any) => (
                  <Card key={request.id} className="bg-slate-800/50 border-slate-700 p-4">
                    <div className="flex items-start justify-between mb-3">
                      <div>
                        <h3 className="font-semibold text-white text-lg">{request.shipType}</h3>
                        <p className="text-sm text-slate-400">Positions: {request.requiredPositions}</p>
                      </div>
                      <Badge
                        className={
                          request.status === "approved"
                            ? "bg-green-900/50 text-green-200 border-green-700"
                            : request.status === "rejected"
                              ? "bg-red-900/50 text-red-200 border-red-700"
                              : "bg-blue-900/50 text-blue-200 border-blue-700"
                        }
                      >
                        {request.status}
                      </Badge>
                    </div>

                    <div className="grid grid-cols-2 gap-4 text-sm mb-3">
                      <div>
                        <p className="text-slate-400">Crew Required</p>
                        <p className="text-white font-semibold">{request.numberOfCrew}</p>
                      </div>
                      {request.contractDuration && (
                        <div>
                          <p className="text-slate-400">Contract Duration</p>
                          <p className="text-white font-semibold">{request.contractDuration}</p>
                        </div>
                      )}
                      {request.salary && (
                        <div>
                          <p className="text-slate-400">Salary</p>
                          <p className="text-white font-semibold">{request.salary}</p>
                        </div>
                      )}
                    </div>

                    {request.requirements && (
                      <div className="pt-3 border-t border-slate-700">
                        <p className="text-slate-400 text-sm">Requirements</p>
                        <p className="text-slate-200 text-sm mt-1">{request.requirements}</p>
                      </div>
                    )}

                    <p className="text-xs text-slate-500 mt-3">
                      Submitted: {new Date(request.createdAt).toLocaleDateString()}
                    </p>
                  </Card>
                ))}
              </div>
            ) : (
              <Card className="bg-slate-800/50 border-slate-700 p-6 text-center">
                <p className="text-slate-400">No crew requests yet. Click "New Crew Request" to get started.</p>
              </Card>
            )}
          </TabsContent>

          {/* Applications Tab */}
          <TabsContent value="applications" className="space-y-4">
            <h2 className="text-2xl font-bold text-white">Seafarer Applications</h2>
            {applicationsQuery.isLoading ? (
              <div className="text-slate-400">Loading applications...</div>
            ) : (applicationsQuery.data || []).length > 0 ? (
              <div className="space-y-3">
                {applicationsQuery.data?.map((app: any) => (
                  <Card key={app.id} className="bg-slate-800/50 border-slate-700 p-4">
                    <div className="flex items-start justify-between mb-3">
                      <div>
                        <h3 className="font-semibold text-white">Seafarer ID: {app.seafarerId}</h3>
                        <p className="text-sm text-slate-400">Applied: {new Date(app.appliedAt).toLocaleDateString()}</p>
                      </div>
                      <Badge
                        className={
                          app.status === "accepted"
                            ? "bg-green-900/50 text-green-200 border-green-700"
                            : app.status === "rejected"
                              ? "bg-red-900/50 text-red-200 border-red-700"
                              : "bg-blue-900/50 text-blue-200 border-blue-700"
                        }
                      >
                        {app.status}
                      </Badge>
                    </div>

                    {app.status === "pending" && (
                      <div className="flex gap-2">
                        <Button
                          size="sm"
                          onClick={() =>
                            reviewApplicationMutation.mutate({
                              applicationId: app.id,
                              status: "accepted",
                            })
                          }
                          className="bg-green-600 hover:bg-green-700 text-white"
                        >
                          Accept
                        </Button>
                        <Button
                          size="sm"
                          onClick={() =>
                            reviewApplicationMutation.mutate({
                              applicationId: app.id,
                              status: "rejected",
                            })
                          }
                          className="bg-red-600 hover:bg-red-700 text-white"
                        >
                          Reject
                        </Button>
                      </div>
                    )}
                  </Card>
                ))}
              </div>
            ) : (
              <Card className="bg-slate-800/50 border-slate-700 p-6 text-center">
                <p className="text-slate-400">No applications yet. Seafarers will apply to your crew requests.</p>
              </Card>
            )}
          </TabsContent>
        </Tabs>
      </div>
    </DashboardLayout>
  );
}
