import { getDb } from "./db";
import { invokeLLM } from "./_core/llm";
import { applications, jobs, seafarers, workExperience, certificates } from "../drizzle/schema";
import { eq } from "drizzle-orm";

/**
 * LLM-powered job matching engine
 * Analyzes seafarer profiles and ranks them against job postings
 */

export interface JobMatch {
  jobId: number;
  seafarerId: number;
  matchScore: number; // 0-100
  reasoning: string;
  keyStrengths: string[];
  gaps: string[];
}

export interface SeafarerMatch {
  seafarerId: number;
  jobId: number;
  matchScore: number; // 0-100
  reasoning: string;
  whyGoodFit: string[];
  recommendedActions: string[];
}

/**
 * Find best-matching jobs for a specific seafarer
 */
export async function findBestJobsForSeafarer(seafarerId: number, limit: number = 5): Promise<SeafarerMatch[]> {
  const db = await getDb();
  if (!db) return [];

  try {
    // Get seafarer profile with experience and certificates
    const seafarer = await db
      .select()
      .from(seafarers)
      .where(eq(seafarers.id, seafarerId))
      .limit(1)
      .then((rows) => rows[0]);

    if (!seafarer) return [];

    // Get seafarer's work experience
    const experience = await db
      .select()
      .from(workExperience)
      .where(eq(workExperience.seafarerId, seafarerId));

    // Get seafarer's certificates
    const certs = await db
      .select()
      .from(certificates)
      .where(eq(certificates.seafarerId, seafarerId));

    // Get all open jobs
    const openJobs = await db
      .select()
      .from(jobs)
      .where(eq(jobs.status, "open"));

    if (openJobs.length === 0) return [];

    // Build seafarer profile summary
    const seafarerProfile = `
Name: ${seafarer.firstName} ${seafarer.lastName}
Rank: ${seafarer.rank || "Not specified"}
Experience: ${seafarer.yearsOfExperience || 0} years
Nationality: ${seafarer.nationality || "Not specified"}

Work Experience:
${experience.map((exp) => `- ${exp.position} at ${exp.companyName} (${exp.startDate.toLocaleDateString()} to ${exp.endDate?.toLocaleDateString() || "Present"})`).join("\n")}

Certificates:
${certs.map((cert) => `- ${cert.certificateType} (Expires: ${cert.expiryDate.toLocaleDateString()})`).join("\n")}

Bio: ${seafarer.bio || "No bio provided"}
    `;

    // Score each job
    const matches: SeafarerMatch[] = [];

    for (const job of openJobs) {
      const jobProfile = `
Title: ${job.title}
Description: ${job.description}
Ship Type: ${job.shipType}
Required Positions: ${job.requiredPositions}
Required Rank: ${job.requiredRank || "Not specified"}
Min Experience: ${job.minExperience || 0} years
Contract Duration: ${job.contractDuration || "Not specified"}
Salary: ${job.salary || "Not specified"}
      `;

      // Use LLM to score the match
      const response = await invokeLLM({
        messages: [
          {
            role: "system",
            content: `You are an expert maritime recruitment consultant. Analyze the seafarer profile and job posting, and provide a match score (0-100) along with reasoning.

Respond in JSON format:
{
  "matchScore": <number 0-100>,
  "reasoning": "<brief explanation of the score>",
  "whyGoodFit": ["<reason 1>", "<reason 2>", ...],
  "recommendedActions": ["<action 1>", "<action 2>", ...]
}`,
          },
          {
            role: "user",
            content: `Seafarer Profile:\n${seafarerProfile}\n\nJob Posting:\n${jobProfile}\n\nProvide a match score and analysis.`,
          },
        ],
        response_format: {
          type: "json_schema",
          json_schema: {
            name: "job_match",
            strict: true,
            schema: {
              type: "object",
              properties: {
                matchScore: { type: "number", description: "Match score 0-100" },
                reasoning: { type: "string", description: "Brief explanation" },
                whyGoodFit: {
                  type: "array",
                  items: { type: "string" },
                  description: "Reasons why this is a good fit",
                },
                recommendedActions: {
                  type: "array",
                  items: { type: "string" },
                  description: "Recommended next steps",
                },
              },
              required: ["matchScore", "reasoning", "whyGoodFit", "recommendedActions"],
              additionalProperties: false,
            },
          },
        },
      });

      try {
        const content = response.choices?.[0]?.message?.content;
        if (typeof content === "string") {
          const parsed = JSON.parse(content);
          matches.push({
            seafarerId,
            jobId: job.id,
            matchScore: parsed.matchScore,
            reasoning: parsed.reasoning,
            whyGoodFit: parsed.whyGoodFit,
            recommendedActions: parsed.recommendedActions,
          });
        }
      } catch (parseError) {
        console.error("Failed to parse LLM response:", parseError);
      }
    }

    // Sort by match score and return top matches
    return matches.sort((a, b) => b.matchScore - a.matchScore).slice(0, limit);
  } catch (error) {
    console.error("Error in findBestJobsForSeafarer:", error);
    return [];
  }
}

/**
 * Find best-matching seafarers for a specific job
 */
export async function findBestSeafarersForJob(jobId: number, limit: number = 10): Promise<JobMatch[]> {
  const db = await getDb();
  if (!db) return [];

  try {
    // Get job details
    const job = await db
      .select()
      .from(jobs)
      .where(eq(jobs.id, jobId))
      .limit(1)
      .then((rows) => rows[0]);

    if (!job) return [];

    // Get all approved seafarers
    const allSeafarers = await db
      .select()
      .from(seafarers)
      .where(eq(seafarers.isApproved, true));

    if (allSeafarers.length === 0) return [];

    // Build job profile
    const jobProfile = `
Title: ${job.title}
Description: ${job.description}
Ship Type: ${job.shipType}
Required Positions: ${job.requiredPositions}
Required Rank: ${job.requiredRank || "Not specified"}
Min Experience: ${job.minExperience || 0} years
Contract Duration: ${job.contractDuration || "Not specified"}
Salary: ${job.salary || "Not specified"}
    `;

    // Score each seafarer
    const matches: JobMatch[] = [];

    for (const seafarer of allSeafarers) {
      // Get seafarer's experience and certificates
      const experience = await db
        .select()
        .from(workExperience)
        .where(eq(workExperience.seafarerId, seafarer.id));

      const certs = await db
        .select()
        .from(certificates)
        .where(eq(certificates.seafarerId, seafarer.id));

      const seafarerProfile = `
Name: ${seafarer.firstName} ${seafarer.lastName}
Rank: ${seafarer.rank || "Not specified"}
Experience: ${seafarer.yearsOfExperience || 0} years
Nationality: ${seafarer.nationality || "Not specified"}

Work Experience:
${experience.map((exp) => `- ${exp.position} at ${exp.companyName} (${exp.startDate.toLocaleDateString()} to ${exp.endDate?.toLocaleDateString() || "Present"})`).join("\n")}

Certificates:
${certs.map((cert) => `- ${cert.certificateType} (Expires: ${cert.expiryDate.toLocaleDateString()})`).join("\n")}

Bio: ${seafarer.bio || "No bio provided"}
      `;

      // Use LLM to score the match
      const response = await invokeLLM({
        messages: [
          {
            role: "system",
            content: `You are an expert maritime recruitment consultant. Analyze the job posting and seafarer profile, and provide a match score (0-100) along with reasoning.

Respond in JSON format:
{
  "matchScore": <number 0-100>,
  "reasoning": "<brief explanation of the score>",
  "keyStrengths": ["<strength 1>", "<strength 2>", ...],
  "gaps": ["<gap 1>", "<gap 2>", ...]
}`,
          },
          {
            role: "user",
            content: `Job Posting:\n${jobProfile}\n\nSeafarer Profile:\n${seafarerProfile}\n\nProvide a match score and analysis.`,
          },
        ],
        response_format: {
          type: "json_schema",
          json_schema: {
            name: "seafarer_match",
            strict: true,
            schema: {
              type: "object",
              properties: {
                matchScore: { type: "number", description: "Match score 0-100" },
                reasoning: { type: "string", description: "Brief explanation" },
                keyStrengths: {
                  type: "array",
                  items: { type: "string" },
                  description: "Key strengths for this job",
                },
                gaps: {
                  type: "array",
                  items: { type: "string" },
                  description: "Skill or experience gaps",
                },
              },
              required: ["matchScore", "reasoning", "keyStrengths", "gaps"],
              additionalProperties: false,
            },
          },
        },
      });

      try {
        const content = response.choices?.[0]?.message?.content;
        if (typeof content === "string") {
          const parsed = JSON.parse(content);
          matches.push({
            jobId,
            seafarerId: seafarer.id,
            matchScore: parsed.matchScore,
            reasoning: parsed.reasoning,
            keyStrengths: parsed.keyStrengths,
            gaps: parsed.gaps,
          });
        }
      } catch (parseError) {
        console.error("Failed to parse LLM response:", parseError);
      }
    }

    // Sort by match score and return top matches
    return matches.sort((a, b) => b.matchScore - a.matchScore).slice(0, limit);
  } catch (error) {
    console.error("Error in findBestSeafarersForJob:", error);
    return [];
  }
}
