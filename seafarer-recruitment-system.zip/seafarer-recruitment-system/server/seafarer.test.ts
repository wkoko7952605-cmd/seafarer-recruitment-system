import { describe, expect, it, beforeEach, vi } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";
import type { User } from "../drizzle/schema";

// Increase timeout for database operations
const TIMEOUT = 15000;

// Mock context for seafarer
function createSeafarerContext(): TrpcContext {
  const user: User = {
    id: 1,
    openId: "seafarer-user",
    email: "seafarer@example.com",
    name: "John Seafarer",
    loginMethod: "manus",
    role: "seafarer",
    createdAt: new Date(),
    updatedAt: new Date(),
    lastSignedIn: new Date(),
  };

  return {
    user,
    req: {
      protocol: "https",
      headers: {},
    } as TrpcContext["req"],
    res: {} as TrpcContext["res"],
  };
}

// Mock context for admin
function createAdminContext(): TrpcContext {
  const user: User = {
    id: 2,
    openId: "admin-user",
    email: "admin@example.com",
    name: "Admin User",
    loginMethod: "manus",
    role: "admin",
    createdAt: new Date(),
    updatedAt: new Date(),
    lastSignedIn: new Date(),
  };

  return {
    user,
    req: {
      protocol: "https",
      headers: {},
    } as TrpcContext["req"],
    res: {} as TrpcContext["res"],
  };
}

// Mock context for employer
function createEmployerContext(): TrpcContext {
  const user: User = {
    id: 3,
    openId: "employer-user",
    email: "employer@example.com",
    name: "Employer User",
    loginMethod: "manus",
    role: "employer",
    createdAt: new Date(),
    updatedAt: new Date(),
    lastSignedIn: new Date(),
  };

  return {
    user,
    req: {
      protocol: "https",
      headers: {},
    } as TrpcContext["req"],
    res: {} as TrpcContext["res"],
  };
}

describe("Seafarer Routes", () => {
  it("should allow seafarer to get their profile", async () => {
    const ctx = createSeafarerContext();
    const caller = appRouter.createCaller(ctx);

    // This will return undefined if no profile exists yet
    const result = await caller.seafarer.getProfile();
    expect(result === undefined || result.userId === ctx.user.id).toBe(true);
  }, { timeout: TIMEOUT });

  it("should reject non-seafarer from accessing seafarer routes", async () => {
    const ctx = createAdminContext();
    const caller = appRouter.createCaller(ctx);

    try {
      await caller.seafarer.getProfile();
      expect.fail("Should have thrown FORBIDDEN error");
    } catch (error: any) {
      expect(error.code).toBe("FORBIDDEN");
    }
  });

  it("should allow seafarer to update profile", async () => {
    const ctx = createSeafarerContext();
    const caller = appRouter.createCaller(ctx);

    const result = await caller.seafarer.updateProfile({
      firstName: "John",
      lastName: "Doe",
      rank: "Captain",
      yearsOfExperience: 15,
    });

    expect(result.success).toBe(true);
  }, { timeout: TIMEOUT });
});

describe("Admin Routes", () => {
  it("should allow admin to get all seafarers", async () => {
    const ctx = createAdminContext();
    const caller = appRouter.createCaller(ctx);

    const result = await caller.admin.getAllSeafarers();
    expect(Array.isArray(result)).toBe(true);
  }, { timeout: TIMEOUT });

  it("should reject non-admin from accessing admin routes", async () => {
    const ctx = createSeafarerContext();
    const caller = appRouter.createCaller(ctx);

    try {
      await caller.admin.getAllSeafarers();
      expect.fail("Should have thrown FORBIDDEN error");
    } catch (error: any) {
      expect(error.code).toBe("FORBIDDEN");
    }
  });

  it("should allow admin to create news", async () => {
    const ctx = createAdminContext();
    const caller = appRouter.createCaller(ctx);

    const result = await caller.admin.createNews({
      title: "Maritime Industry Update",
      content: "New regulations for maritime safety...",
      category: "Regulations",
    });

    expect(result.success).toBe(true);
  }, { timeout: TIMEOUT });
});

describe("Employer Routes", () => {
  it("should allow employer to get their profile", async () => {
    const ctx = createEmployerContext();
    const caller = appRouter.createCaller(ctx);

    const result = await caller.employer.getProfile();
    expect(result === undefined || result.userId === ctx.user.id).toBe(true);
  });

  it("should reject non-employer from accessing employer routes", async () => {
    const ctx = createSeafarerContext();
    const caller = appRouter.createCaller(ctx);

    try {
      await caller.employer.getProfile();
      expect.fail("Should have thrown FORBIDDEN error");
    } catch (error: any) {
      expect(error.code).toBe("FORBIDDEN");
    }
  });

  it("should allow employer to update profile", async () => {
    const ctx = createEmployerContext();
    const caller = appRouter.createCaller(ctx);

    const result = await caller.employer.updateProfile({
      companyName: "Maritime Shipping Co.",
      industry: "Shipping",
      country: "Singapore",
    });

    expect(result.success).toBe(true);
  }, { timeout: TIMEOUT });
});

describe("Public Routes", () => {
  it("should allow public access to news", async () => {
    const ctx = createSeafarerContext();
    const caller = appRouter.createCaller(ctx);

    const result = await caller.public.getNews();
    expect(Array.isArray(result)).toBe(true);
  });

  it("should allow public access to job listings", async () => {
    const ctx = createSeafarerContext();
    const caller = appRouter.createCaller(ctx);

    const result = await caller.jobs.list();
    expect(Array.isArray(result)).toBe(true);
  });
});

describe("Job Routes", () => {
  it("should allow admin to create jobs", async () => {
    const ctx = createAdminContext();
    const caller = appRouter.createCaller(ctx);

    const result = await caller.jobs.create({
      title: "Chief Engineer",
      description: "Seeking experienced chief engineer",
      shipType: "Container Ship",
      requiredPositions: "Chief Engineer",
      minExperience: 10,
    });

    expect(result.success).toBe(true);
  }, { timeout: TIMEOUT });

  it("should reject non-admin from creating jobs", async () => {
    const ctx = createSeafarerContext();
    const caller = appRouter.createCaller(ctx);

    try {
      await caller.jobs.create({
        title: "Chief Engineer",
        description: "Seeking experienced chief engineer",
        shipType: "Container Ship",
        requiredPositions: "Chief Engineer",
      });
      expect.fail("Should have thrown FORBIDDEN error");
    } catch (error: any) {
      expect(error.code).toBe("FORBIDDEN");
    }
  }, { timeout: TIMEOUT });
});
