import { eq, sql } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { InsertUser, users, seafarers, certificates, jobs, applications, employers, workExperience, documents, maritimeNews } from "../drizzle/schema";
import { ENV } from './_core/env';

let _db: ReturnType<typeof drizzle> | null = null;

// Lazily create the drizzle instance so local tooling can run without a DB.
export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) {
    throw new Error("User openId is required for upsert");
  }

  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }

  try {
    const values: InsertUser = {
      openId: user.openId,
    };
    const updateSet: Record<string, unknown> = {};

    const textFields = ["name", "email", "loginMethod"] as const;
    type TextField = (typeof textFields)[number];

    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };

    textFields.forEach(assignNullable);

    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = 'admin';
      updateSet.role = 'admin';
    }

    if (!values.lastSignedIn) {
      values.lastSignedIn = new Date();
    }

    if (Object.keys(updateSet).length === 0) {
      updateSet.lastSignedIn = new Date();
    }

    await db.insert(users).values(values).onDuplicateKeyUpdate({
      set: updateSet,
    });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return undefined;
  }

  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);

  return result.length > 0 ? result[0] : undefined;
}

// Seafarer queries
export async function getSeafarerByUserId(userId: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(seafarers).where(eq(seafarers.userId, userId)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function getAllSeafarers() {
  const db = await getDb();
  if (!db) return [];
  return await db.select().from(seafarers);
}

// Certificate queries
export async function getCertificatesBySeafarerId(seafarerId: number) {
  const db = await getDb();
  if (!db) return [];
  return await db.select().from(certificates).where(eq(certificates.seafarerId, seafarerId));
}

export async function getExpiringCertificates(daysThreshold: number) {
  const db = await getDb();
  if (!db) return [];
  // Find certificates expiring within the threshold
  const today = new Date();
  const thresholdDate = new Date(today.getTime() + daysThreshold * 24 * 60 * 60 * 1000);
  return await db.select().from(certificates).where(
    sql`${certificates.expiryDate} <= ${thresholdDate} AND ${certificates.expiryDate} > ${today}`
  );
}

// Job queries
export async function getAllJobs() {
  const db = await getDb();
  if (!db) return [];
  return await db.select().from(jobs).where(eq(jobs.status, 'open'));
}

export async function getJobById(jobId: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(jobs).where(eq(jobs.id, jobId)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

// Application queries
export async function getApplicationsBySeafarerId(seafarerId: number) {
  const db = await getDb();
  if (!db) return [];
  return await db.select().from(applications).where(eq(applications.seafarerId, seafarerId));
}

export async function getApplicationsByJobId(jobId: number) {
  const db = await getDb();
  if (!db) return [];
  return await db.select().from(applications).where(eq(applications.jobId, jobId));
}

// Employer queries
export async function getEmployerByUserId(userId: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(employers).where(eq(employers.userId, userId)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

// Work experience queries
export async function getWorkExperienceBySeafarerId(seafarerId: number) {
  const db = await getDb();
  if (!db) return [];
  return await db.select().from(workExperience).where(eq(workExperience.seafarerId, seafarerId));
}

// Document queries
export async function getDocumentsBySeafarerId(seafarerId: number) {
  const db = await getDb();
  if (!db) return [];
  return await db.select().from(documents).where(eq(documents.seafarerId, seafarerId));
}

// Maritime news queries
export async function getPublishedNews() {
  const db = await getDb();
  if (!db) return [];
  return await db.select().from(maritimeNews).where(eq(maritimeNews.isPublished, true));
}
