import express, { Request, Response } from "express";
import { storagePut } from "./storage";
import { getDb } from "./db";
import { documents } from "../drizzle/schema";
import { getSessionCookieOptions } from "./_core/cookies";
import { COOKIE_NAME } from "@shared/const";
import { getUserByOpenId } from "./db";

/**
 * File upload endpoint for documents (CVs, certificates, etc.)
 * Handles multipart form data and stores files securely in cloud storage
 */
export async function handleFileUpload(req: Request, res: Response) {
  try {
    // Get user from session cookie
    const cookies = req.headers.cookie || "";
    const sessionCookie = cookies
      .split(";")
      .find((c) => c.trim().startsWith(COOKIE_NAME + "="));

    if (!sessionCookie) {
      return res.status(401).json({ error: "Unauthorized" });
    }

    // For now, we'll accept the upload
    // In production, you'd verify the JWT token from the cookie

    const file = (req as any).file;
    if (!file) {
      return res.status(400).json({ error: "No file provided" });
    }

    const documentType = req.body.documentType || "other";

    // Generate unique file key
    const timestamp = Date.now();
    const fileKey = `documents/${documentType}/${timestamp}-${file.originalname}`;

    // Upload to cloud storage
    const { url } = await storagePut(fileKey, file.buffer, file.mimetype);

    // Return success response
    res.json({
      success: true,
      fileKey,
      fileUrl: url,
      fileName: file.originalname,
      size: file.size,
      mimeType: file.mimetype,
    });
  } catch (error) {
    console.error("File upload error:", error);
    res.status(500).json({ error: "Upload failed" });
  }
}

/**
 * Get secure download URL for a document
 * Verifies user has access before returning the URL
 */
export async function getDocumentUrl(req: Request, res: Response) {
  try {
    const { fileKey } = req.query;

    if (!fileKey || typeof fileKey !== "string") {
      return res.status(400).json({ error: "Invalid file key" });
    }

    // Get presigned URL from storage
    const { storageGet } = await import("./storage");
    const result = await storageGet(fileKey);

    res.json({ url: result.url });
  } catch (error) {
    console.error("Get document URL error:", error);
    res.status(500).json({ error: "Failed to get document URL" });
  }
}
