import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, protectedProcedure, router } from "./_core/trpc";
import { TRPCError } from "@trpc/server";
import { z } from "zod";
import { eq, sql } from "drizzle-orm";
import { getDb } from "./db";
import {
  getSeafarerByUserId,
  getAllSeafarers,
  getCertificatesBySeafarerId,
  getAllJobs,
  getJobById,
  getApplicationsBySeafarerId,
  getApplicationsByJobId,
  getEmployerByUserId,
  getWorkExperienceBySeafarerId,
  getDocumentsBySeafarerId,
  getPublishedNews,
  getExpiringCertificates,
} from "./db";
import {
  seafarers,
  certificates,
  jobs,
  applications,
  employers,
  workExperience,
  documents,
  maritimeNews,
  notificationLogs,
} from "../drizzle/schema";

// Role-based procedure helpers
const seafarerProcedure = protectedProcedure.use(async ({ ctx, next }) => {
  if (ctx.user.role !== "seafarer") {
    throw new TRPCError({ code: "FORBIDDEN", message: "Seafarer access required" });
  }
  return next({ ctx });
});

const employerProcedure = protectedProcedure.use(async ({ ctx, next }) => {
  if (ctx.user.role !== "employer") {
    throw new TRPCError({ code: "FORBIDDEN", message: "Employer access required" });
  }
  return next({ ctx });
});

const adminProcedure = protectedProcedure.use(async ({ ctx, next }) => {
  if (ctx.user.role !== "admin") {
    throw new TRPCError({ code: "FORBIDDEN", message: "Admin access required" });
  }
  return next({ ctx });
});

export const appRouter = router({
  system: systemRouter,
  
  auth: router({
    me: publicProcedure.query((opts) => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return { success: true } as const;
    }),
  }),

  // Seafarer routes
  seafarer: router({
    // Get or create seafarer profile
    getProfile: seafarerProcedure.query(async ({ ctx }) => {
      return await getSeafarerByUserId(ctx.user.id);
    }),

    // Create/update seafarer profile
    updateProfile: seafarerProcedure.input(
      z.object({
        firstName: z.string().min(1),
        lastName: z.string().min(1),
        dateOfBirth: z.string().optional(),
        nationality: z.string().optional(),
        passportNumber: z.string().optional(),
        rank: z.string().optional(),
        yearsOfExperience: z.number().optional(),
        bio: z.string().optional(),
      })
    ).mutation(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });

      const existing = await getSeafarerByUserId(ctx.user.id);
      
      if (existing) {
        await db
          .update(seafarers)
          .set({
            firstName: input.firstName,
            lastName: input.lastName,
            dateOfBirth: input.dateOfBirth ? new Date(input.dateOfBirth) : undefined,
            nationality: input.nationality,
            passportNumber: input.passportNumber,
            rank: input.rank,
            yearsOfExperience: input.yearsOfExperience,
            bio: input.bio,
            updatedAt: new Date(),
          })
          .where(eq(seafarers.id, existing.id));
        return { success: true, id: existing.id };
      } else {
        await db.insert(seafarers).values({
          userId: ctx.user.id,
          firstName: input.firstName,
          lastName: input.lastName,
          dateOfBirth: input.dateOfBirth ? new Date(input.dateOfBirth) : undefined,
          nationality: input.nationality,
          passportNumber: input.passportNumber,
          rank: input.rank,
          yearsOfExperience: input.yearsOfExperience,
          bio: input.bio,
        });
        return { success: true };
      }
    }),

    // Get certificates
    getCertificates: seafarerProcedure.query(async ({ ctx }) => {
      const seafarer = await getSeafarerByUserId(ctx.user.id);
      if (!seafarer) throw new TRPCError({ code: "NOT_FOUND" });
      return await getCertificatesBySeafarerId(seafarer.id);
    }),

    // Add certificate
    addCertificate: seafarerProcedure.input(
      z.object({
        certificateType: z.string().min(1),
        certificateNumber: z.string().optional(),
        issuedDate: z.string().optional(),
        expiryDate: z.string().min(1),
        issuingCountry: z.string().optional(),
        fileKey: z.string().optional(),
        fileUrl: z.string().optional(),
      })
    ).mutation(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });

      const seafarer = await getSeafarerByUserId(ctx.user.id);
      if (!seafarer) throw new TRPCError({ code: "NOT_FOUND" });

      await db.insert(certificates).values({
        seafarerId: seafarer.id,
        certificateType: input.certificateType,
        certificateNumber: input.certificateNumber,
        issuedDate: input.issuedDate ? new Date(input.issuedDate) : undefined,
        expiryDate: new Date(input.expiryDate),
        issuingCountry: input.issuingCountry,
        fileKey: input.fileKey,
        fileUrl: input.fileUrl,
      });

      return { success: true };
    }),

    // Get work experience
    getWorkExperience: seafarerProcedure.query(async ({ ctx }) => {
      const seafarer = await getSeafarerByUserId(ctx.user.id);
      if (!seafarer) throw new TRPCError({ code: "NOT_FOUND" });
      return await getWorkExperienceBySeafarerId(seafarer.id);
    }),

    // Add work experience
    addWorkExperience: seafarerProcedure.input(
      z.object({
        companyName: z.string().min(1),
        position: z.string().min(1),
        shipType: z.string().optional(),
        startDate: z.string().min(1),
        endDate: z.string().optional(),
        description: z.string().optional(),
      })
    ).mutation(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });

      const seafarer = await getSeafarerByUserId(ctx.user.id);
      if (!seafarer) throw new TRPCError({ code: "NOT_FOUND" });

      await db.insert(workExperience).values({
        seafarerId: seafarer.id,
        companyName: input.companyName,
        position: input.position,
        shipType: input.shipType,
        startDate: new Date(input.startDate),
        endDate: input.endDate ? new Date(input.endDate) : undefined,
        description: input.description,
      });

      return { success: true };
    }),

    // Get documents
    getDocuments: seafarerProcedure.query(async ({ ctx }) => {
      const seafarer = await getSeafarerByUserId(ctx.user.id);
      if (!seafarer) throw new TRPCError({ code: "NOT_FOUND" });
      return await getDocumentsBySeafarerId(seafarer.id);
    }),

    // Get applications
    getApplications: seafarerProcedure.query(async ({ ctx }) => {
      const seafarer = await getSeafarerByUserId(ctx.user.id);
      if (!seafarer) throw new TRPCError({ code: "NOT_FOUND" });
      return await getApplicationsBySeafarerId(seafarer.id);
    }),
  }),

  // Job routes
  jobs: router({
    // List all open jobs
    list: publicProcedure.query(async () => {
      return await getAllJobs();
    }),

    // Get job details
    getById: publicProcedure.input(z.object({ id: z.number() })).query(async ({ input }) => {
      return await getJobById(input.id);
    }),

    // Create job (admin only)
    create: adminProcedure.input(
      z.object({
        title: z.string().min(1),
        description: z.string().min(1),
        shipType: z.string().min(1),
        requiredPositions: z.string().min(1),
        requiredRank: z.string().optional(),
        minExperience: z.number().optional(),
        salary: z.string().optional(),
        contractDuration: z.string().optional(),
        location: z.string().optional(),
      })
    ).mutation(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });

      const result = await db.insert(jobs).values({
        ...input,
        createdBy: ctx.user.id,
      });

      return { success: true };
    }),

    // Apply for job (seafarer only)
    submitApplication: seafarerProcedure.input(z.object({ jobId: z.number() })).mutation(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });

      const seafarer = await getSeafarerByUserId(ctx.user.id);
      if (!seafarer) throw new TRPCError({ code: "NOT_FOUND" });

      // Check if already applied
      const existing = await db
        .select()
        .from(applications)
        .where(
          sql`${applications.jobId} = ${input.jobId} AND ${applications.seafarerId} = ${seafarer.id}`
        )
        .limit(1);

      if (existing.length > 0) {
        throw new TRPCError({ code: "BAD_REQUEST", message: "Already applied for this job" });
      }

      const result = await db.insert(applications).values({
        jobId: input.jobId,
        seafarerId: seafarer.id,
      });

      return { success: true };
    }),
  }),

  // Employer routes
  employer: router({
    // Get employer profile
    getProfile: employerProcedure.query(async ({ ctx }) => {
      return await getEmployerByUserId(ctx.user.id);
    }),

    // Update employer profile
    updateProfile: employerProcedure.input(
      z.object({
        companyName: z.string().min(1),
        registrationNumber: z.string().optional(),
        industry: z.string().optional(),
        country: z.string().optional(),
        contactPerson: z.string().optional(),
        contactEmail: z.string().email().optional(),
        contactPhone: z.string().optional(),
        companyDescription: z.string().optional(),
      })
    ).mutation(async ({ ctx, input }: any) => {
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });

      const existing = await getEmployerByUserId(ctx.user.id);

      if (existing) {
        await db
          .update(employers)
          .set({
            companyName: input.companyName,
            registrationNumber: input.registrationNumber,
            industry: input.industry,
            country: input.country,
            contactPerson: input.contactPerson,
            contactEmail: input.contactEmail,
            contactPhone: input.contactPhone,
            companyDescription: input.companyDescription,
            updatedAt: new Date(),
          })
          .where(eq(employers.id, existing.id));
        return { success: true, id: existing.id };
      } else {
        await db.insert(employers).values({
          userId: ctx.user.id,
          companyName: input.companyName,
          registrationNumber: input.registrationNumber,
          industry: input.industry,
          country: input.country,
          contactPerson: input.contactPerson,
          contactEmail: input.contactEmail,
          contactPhone: input.contactPhone,
          companyDescription: input.companyDescription,
        });
        return { success: true };
      }
    }),

    // Get crew requests
    getCrewRequests: employerProcedure.query(async ({ ctx }) => {
      return [];
    }),

    // Submit crew request
    submitCrewRequest: employerProcedure.input(
      z.object({
        shipType: z.string().min(1),
        requiredPositions: z.string().min(1),
        numberOfCrew: z.number().min(1),
        contractDuration: z.string().optional(),
        salary: z.string().optional(),
        requirements: z.string().optional(),
      })
    ).mutation(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });
      const employer = await getEmployerByUserId(ctx.user.id);
      if (!employer) throw new TRPCError({ code: "NOT_FOUND", message: "Employer not found" });
      return { success: true };
    }),

    // Get applications for employer
    getApplications: employerProcedure.query(async () => {
      return [];
    }),

    // Review application
    reviewApplication: employerProcedure.input(
      z.object({
        applicationId: z.number(),
        status: z.enum(["accepted", "rejected"]),
      })
    ).mutation(async ({ input }: any) => {
      return { success: true };
    }),
  }),

  // Admin routes
  admin: router({
    // Get all seafarers
    getAllSeafarers: adminProcedure.query(async () => {
      return await getAllSeafarers();
    }),

    // Approve seafarer
    approveSeafarer: adminProcedure.input(z.object({ seafarerId: z.number() })).mutation(async ({ input }) => {
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });

      await db
        .update(seafarers)
        .set({ isApproved: true })
        .where(eq(seafarers.id, input.seafarerId));

      return { success: true };
    }),

    // Get applications for a job
    getJobApplications: adminProcedure.input(z.object({ jobId: z.number() })).query(async ({ input }) => {
      return await getApplicationsByJobId(input.jobId);
    }),

    // Review application
    reviewApplication: adminProcedure.input(
      z.object({
        applicationId: z.number(),
        status: z.enum(["accepted", "rejected"]),
      })
    ).mutation(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });

      await db
        .update(applications)
        .set({
          status: input.status,
          reviewedAt: new Date(),
          reviewedBy: ctx.user.id,
        })
        .where(eq(applications.id, input.applicationId));

      return { success: true };
    }),

    // Get maritime news
    getNews: adminProcedure.query(async () => {
      const db = await getDb();
      if (!db) return [];
      return await db.select().from(maritimeNews);
    }),

    // Create news
    createNews: adminProcedure.input(
      z.object({
        title: z.string().min(1),
        content: z.string().min(1),
        category: z.string().optional(),
        imageUrl: z.string().optional(),
      })
    ).mutation(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });

      const result = await db.insert(maritimeNews).values({
        ...input,
        createdBy: ctx.user.id,
      });

      return { success: true };
    }),

    // Publish news
    publishNews: adminProcedure.input(z.object({ newsId: z.number() })).mutation(async ({ input }) => {
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });

      await db
        .update(maritimeNews)
        .set({
          isPublished: true,
          publishedAt: new Date(),
        })
        .where(eq(maritimeNews.id, input.newsId));

      return { success: true };
    }),
  }),

  // Public routes
  public: router({
    // Get published news
    getNews: publicProcedure.query(async () => {
      return await getPublishedNews();
    }),
  }),
});

export type AppRouter = typeof appRouter;
