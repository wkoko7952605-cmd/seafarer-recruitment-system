import { Request, Response } from "express";
import { getDb } from "../db";
import { certificates, notificationLogs, seafarers, users } from "../../drizzle/schema";
import { eq, gte, lt, and } from "drizzle-orm";
import { sdk } from "../_core/sdk";

/**
 * Handler for daily certificate expiry check
 * Checks for certificates expiring in 30, 60, and 90 days
 * Sends email notifications to seafarers and admin
 */
export async function handleCertificateExpiryCheck(req: Request, res: Response) {
  try {
    // Authenticate as cron
    const user = await sdk.authenticateRequest(req);
    if (!user.isCron) {
      return res.status(403).json({ error: "cron-only" });
    }

    const db = await getDb();
    if (!db) {
      return res.status(500).json({ error: "Database connection failed" });
    }

    // Get all certificates expiring in 30, 60, or 90 days
    const now = new Date();
    const expiryThresholds = [30, 60, 90]; // days
    let notificationsCount = 0;

    for (const days of expiryThresholds) {
      const expiryDate = new Date(now.getTime() + days * 24 * 60 * 60 * 1000);
      const nextDay = new Date(expiryDate.getTime() + 24 * 60 * 60 * 1000);

      // Find certificates expiring within this day
      const expiringCerts = await db
        .select()
        .from(certificates)
        .where(
          and(
            gte(certificates.expiryDate, expiryDate),
            lt(certificates.expiryDate, nextDay)
          )
        );

      for (const cert of expiringCerts) {
        // Get seafarer details
        const seafarer = await db
          .select()
          .from(seafarers)
          .where(eq(seafarers.id, cert.seafarerId))
          .limit(1)
          .then((rows) => rows[0]);

        if (!seafarer) continue;

        // Get user email
        const seafarerUser = await db
          .select()
          .from(users)
          .where(eq(users.id, seafarer.userId))
          .limit(1)
          .then((rows) => rows[0]);

        if (!seafarerUser?.email) continue;

        // Check if we already sent notification for this certificate on this day
        const existingNotification = await db
          .select()
          .from(notificationLogs)
          .where(
            and(
              eq(notificationLogs.certificateId, cert.id),
              eq(notificationLogs.notificationType, `expiry_${days}d`)
            )
          )
          .limit(1)
          .then((rows) => rows[0]);

        if (existingNotification) {
          continue; // Already notified
        }

        // Send email notification to seafarer
        const emailContent = `
Dear ${seafarer.firstName} ${seafarer.lastName},

Your ${cert.certificateType} certificate will expire in ${days} days on ${cert.expiryDate.toLocaleDateString()}.

Please renew your certificate as soon as possible to maintain your eligibility for maritime positions.

Certificate Details:
- Type: ${cert.certificateType}
- Certificate Number: ${cert.certificateNumber || "N/A"}
- Expiry Date: ${cert.expiryDate.toLocaleDateString()}

Best regards,
Maritime Crew Management System
        `;

        // Log notification
        await db.insert(notificationLogs).values({
          recipientId: seafarer.userId,
          certificateId: cert.id,
          notificationType: `expiry_${days}d`,
          subject: `Certificate Expiry Alert: ${cert.certificateType}`,
          message: emailContent,
          status: "sent",
          sentAt: new Date(),
        });

        notificationsCount++;

        // TODO: Integrate with email service to actually send emails
        // For now, just log that we would send
        console.log(`[Certificate Expiry] Would send ${days}d expiry notification to ${seafarerUser.email}`);
      }
    }

    res.json({
      ok: true,
      notificationsProcessed: notificationsCount,
      timestamp: new Date().toISOString(),
    });
  } catch (error: any) {
    console.error("[Certificate Expiry Handler] Error:", error);
    res.status(500).json({
      error: error.message || "Internal server error",
      stack: error.stack,
      context: {
        url: req.url,
        timestamp: new Date().toISOString(),
      },
    });
  }
}


